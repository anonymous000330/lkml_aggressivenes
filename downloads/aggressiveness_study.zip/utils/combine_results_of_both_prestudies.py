import pandas as pd


def combine_results_of_both_prestudies(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    # Combine lables
    study1_labels = "../final_batch_labels" + m + "_excl_unsure.csv"
    study2_labels = "../final_batch_labels2" + m + "_excl_unsure.csv"
    labels_df1 = pd.read_csv(study1_labels, sep=";")
    labels_df2 = pd.read_csv(study2_labels, sep=";")
    labels_both_studies = pd.concat([labels_df1, labels_df2], ignore_index = True)
    labels_both_studies.to_csv(path_or_buf = "../final_both_prestudies_labels" + m + "_excl_unsure.csv", sep = ";", index = False)

    # Combine scores
    tools = ["perspective", "VADER", "stanford", "sentistrength"]
    processings = ["4_maximal_processing_", "3_advanced_processing_", "2_simple_processing_", "1_minimal_processing_"]

    prestudies = ["../batch_2019-04-15", "../batch_2019-10-18"]
    both_studies = "../both_prestudies"

    scores_suffix = "scores.csv"

    # for tool in tools:
    #     for processing in processings:

    #         studies_df = pd.DataFrame()
    #         for batch in prestudies:
    #             filename = "_".join([batch, processing, tool, scores_suffix])
    #             study_df = pd.read_csv(filename , sep=";", header = None)
    #             studies_df = pd.concat([studies_df, study_df], ignore_index = True)
    #         studies_df.to_csv(path_or_buf = "_".join([both_studies, processing, tool, scores_suffix]), sep = ";", header = None, index = False)

