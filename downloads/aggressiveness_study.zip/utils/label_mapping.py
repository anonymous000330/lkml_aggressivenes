import pandas as pd
import numpy as np


def get_label_histogram(df, label="overall_label_median"):
    """
    prints the histogram of a dataframe for the given label (name of df column); e.g., to determine class balance

    :param df: dataframe of final labels
    :param label: string; column name of the label in the df
    :return:
    """

    df[label] = df[label].apply(lambda x: round(x * 10, 0))
    values = pd.unique(df[label])
    values.sort()

    n = 0

    for v in values:
        count = len(df.loc[df[label] == v])
        print("index: " + str(v) + ":  " + str(count))
        n += count

    return n


def get_final_labels(annotations_file, remove_unsure=False, write_output=False, outfile=None, mode=None):
    single_mapped_labels_df = map_single_labels(annotations_file, False, None)
    finals_df = compute_final_labels(single_mapped_labels_df, remove_unsure, write_output, outfile, mode)
    return finals_df


def map_single_labels(annotations_file, write_output=False, outfile=None):
    """

    :param annotations_file:
    :param write_output:
    :param outfile:
    :return:
    """
    df = pd.read_csv(annotations_file, sep=",")

    # 1. aggregated labels
    all_labels = df[
        ['label', 'target_recipient', 'target_thirdparty', 'target_technical', 'target_self', 'target_quoted',
         'target_other', 'target_none', 'not_sure', 'meta']].values
    single_aggregated_labels = [get_compressed_label(*row) for row in all_labels]
    df["aggregated_label"] = pd.Series(single_aggregated_labels, index=df.index)

    # 2. overall labels
    single_overall_labels = [get_overall_label(label) for label in df['label'].values]
    df["overall_label"] = pd.Series(single_overall_labels, index=df.index)

    # 3. senti labels
    senti_labels = [get_sentiment_labels(label) for label in df['label'].values]
    senti_positive = [label[0] for label in senti_labels]
    senti_negative = [label[1] for label in senti_labels]
    df["senti_label_positive"] = pd.Series(senti_positive, index=df.index)
    df["senti_label_negative"] = pd.Series(senti_negative, index=df.index)

    if write_output or (outfile is not None):  # write output to file
        if outfile is None:
            outfile = annotations_file[:-4] + "_mapped_Labels.csv"
        df.to_csv(outfile, sep=';', index=False)

    return df


DUMMY_VALUE = 5000
MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"

def do_all_but_one_agree(s):
    x = s.tolist()
    if len(x) > 2 and max(sum(y <= 0.5 for y in x), sum(y > 0.5 for y in x)) >= (len(x) - 1):
        return np.median(x)
    else:
        # dummy value denoting that there is no agreement (or just two values)        
        return DUMMY_VALUE

def compute_final_labels(mapped_annotations_df, remove_unsure=False, write_output=False, outfile=None, mode=None):
    # 1.1 remove all annotations that are marked as other
    new_df = remove_other_annotations(mapped_annotations_df, entire_msg_group_only=False, threshold=4)

    if remove_unsure:
        if mode == MODE_ONE_AGGRESSIVE:
            new_df = remove_unsure_annotations(new_df, threshold=-1)
        else:
            new_df = remove_unsure_annotations(new_df, threshold=-1)

    if mode == MODE_ALL_BUT_ONE_AGREE:
        final_labels = new_df[["email_id", "aggregated_label", "overall_label", "senti_label_positive", "senti_label_negative"]].groupby('msg_id').agg([do_all_but_one_agree, np.median]).round(3)
        
    elif mode == MODE_ONE_AGGRESSIVE:
        final_labels = new_df[["email_id", "aggregated_label", "overall_label", "senti_label_positive", "senti_label_negative"]].groupby('msg_id').agg([np.max, np.min]).round(3)

    else:
        final_labels = new_df[["email_id", "aggregated_label", "overall_label", "senti_label_positive", "senti_label_negative"]].groupby('msg_id').agg([np.mean, np.median]).round(3)

    #  merge column headers (e.g., there is a column mean and a column median for aggregated_label,.
    # This join the split column headers into: aggregated_label_mean and aggregated_label_median
    new_column_headers = ['_'.join(t) for t in final_labels.columns]
    final_labels.columns = new_column_headers

    if mode == MODE_ALL_BUT_ONE_AGREE:
        # remove messages with missing agreement
        final_labels = final_labels[final_labels["overall_label_do_all_but_one_agree"] < DUMMY_VALUE]
    elif mode == MODE_ONE_AGGRESSIVE:
        # As the maximum of senti_label_negative should actually be its minimum,
        # swap minimum and maximum of senti_label_negative
        columns_to_swap = new_column_headers[6], new_column_headers[7]
        new_column_headers[7], new_column_headers[6] = columns_to_swap
        final_labels = final_labels.reindex(columns = new_column_headers)

    if write_output or (outfile is not None):  # write output to file
        one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
        all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
        unsure = one_aggressive + all_but_one_agree + ("_excl" if remove_unsure else "_incl") + "_unsure.csv"

        if outfile is None:
            outfile = "final_labels_" + unsure
        elif outfile.endswith('.csv'):
            outfile = outfile[:-4] + unsure
        else:
            outfile = outfile + unsure

        final_labels.to_csv(outfile, sep=';', index=True)

    return final_labels


def get_sentiment_labels(label, not_sure=False, invalidate_when_not_sure=False):
    """
    returns two sentiment labels, based on SentiStrengthts format:
    (1,-1) ...neutral (1 not positive, -1 = not negative)
    (5,-1) ... 5 extremely positive, -1 not negative
    (1,-5) ... 1 not positive, -5 extremely negative
    :param label:
    :param not_sure:
    :param invalidate_when_not_sure:
    :return:
    """
    if not_sure and invalidate_when_not_sure:  # option to leave out not_sure annotation
        return np.nan, np.nan

    label_mapping_table = {
        -3: (1, -5),
        -2: (1, -3),
        0: (np.nan, np.nan),
        1: (1, -1),
        2: (5, -1)
    }

    new_label = label_mapping_table[label]

    return new_label


def get_overall_label(label, not_sure=False, invalidate_when_not_sure=False):
    # map labels to either aggressive (1) or not aggressive (0), but allow steps in between
    # -3... very aggressive, -2 mildly aggressive, 1 ... neutral, 2 ... friendly

    if not_sure and invalidate_when_not_sure:  # option to leave out not_sure annotation
        return np.nan

    label_mapping_table = {
        -3: 1,
        -2: 0.7,
        0: np.nan,
        1: 0.3,
        2: 0
    }

    new_label = label_mapping_table[label]

    return new_label


def get_compressed_label(label, target_recipient, target_thirdparty, target_technical, target_self, target_quoted,
                         target_other, target_none, not_sure, meta, invalidate_when_not_sure=False):
    """

    :param label: overall label, possible values: [-3, -2, 0, 1, 2]
    :param target_recipient: possible values: [0, 1]
    :param target_thirdparty:  possible values: [0, 1]
    :param target_technical:  possible values: [0, 1]
    :param target_self:  possible values: [0, 1]
    :param target_quoted:  possible values: [0, 1]
    :param target_other:  possible values: [0, 1]
    :param target_none:  possible values: [0, 1]
    :param not_sure:  possible values: [0, 1]
    :param meta:  possible values: [0, 1]
    :param invalidate_when_not_sure: if True, the given annotation will be invalidated (label becomes np.nan)
    :return: if valid, a float between 0 and 1, otherwise np.nan
    """

    new_label = get_overall_label(label)

    # for corrupted, auto-generated/spam
    if new_label is np.nan or (invalidate_when_not_sure and not_sure):
        return np.nan

    if not_sure:  # incorporate annotator's uncertainty
        if label == 2:
            new_label += 0.15
        elif label == 1:
            pass
        elif label == -2:
            pass
        elif label == -3:
            new_label -= 0.15

    if target_recipient:
        new_label += 0.1

    if target_thirdparty:
        new_label += 0.07

    if target_self:
        new_label -= 0.07

    if target_quoted:
        new_label -= 0.05

    if target_technical:
        pass

    if target_other:
        pass

    if target_none:
        pass

    if meta:
        pass

    if new_label > 1:
        new_label = 1

    if new_label < 0:
        new_label = 0

    return round(new_label, 3)


def get_labels_per_user(df_single_labels, users=[], remove_other=True, remove_unsure=False, binary_labels=False):
    """
     returns overall labels and aggregated labels in a dict with a list of lists.
     the labels are grouped by user: e.g.:
     {"overall_labels_per_user": [[1, 2, 1, 0] # annotator 1
                                [2, 2, 0, 0] # annotator 2
                                ],
            "aggregated_labels_per_user": [[1, 2, 1, 0] # annotator 1
                                            [2, 2, 0, 0] # annotator 2
                                ],}

    :param df_single_labels:
    :param users:
    :param remove_other:
    :param remove_unsure:
    :param binary_labels:
    :return: {"overall_labels_per_user": [[]],
            "aggregated_labels_per_user": [[]]}
    """

    if not users:
        users = df_single_labels.user_id.unique()

    if remove_other:
        df = remove_other_annotations(df_single_labels, entire_msg_group_only=True)
    else:
        df = df_single_labels

    df = df[df.user_id.isin(users)]   # only take into account users given in users param

    if remove_unsure:
        # instead of dropping the rows altogether, we replace them with NAN
        df = remove_unsure_annotations(df, threshold=3, replace_cols_w_NAN=["aggregated_label", "overall_label"])
        #df = remove_unsure_annotations(df, threshold=-1, replace_cols_w_NAN=["aggregated_label", "overall_label"])

    msgs = df.email_id.unique()

    # as not every user has labeled every e-mail, add rows with NAN for a (user,e-mail) pair if a user has not
    # labeled the respective e-mail
    for user in users:
        for msg in msgs:
            if df[(df.email_id == msg) & (df.user_id == user)].empty:
                df = pd.concat([df, pd.DataFrame.from_records([{"email_id":msg, "user_id":user}], index="email_id")])
    # sort dataframe so that e-mails are in same order for all users
    df = df.sort_values(["email_id", "user_id"])

    overall_labels_per_user = []
    aggregated_labels_per_user = []

    target_technical_per_user = []
    target_recipient_per_user = []
    target_other_per_user = []

    user_groups = df[["email_id", "user_id", "overall_label", "aggregated_label"]].groupby('user_id')

    for name, group in user_groups:

        if name not in users:
            continue

        if binary_labels:
            overall_labels = np.round(group.overall_label.values)
            aggregated_labels = np.round(group.aggregated_label.values)

        else:
            overall_labels = (group.overall_label.values * 10)
            aggregated_labels = np.round(group.aggregated_label.values * 10, 0)

        if len(group) < len(msgs):
            raise Exception("There is something wrong with the number of labeled e-mails")

        overall_labels_per_user.append(overall_labels.tolist())
        aggregated_labels_per_user.append(aggregated_labels.tolist())

    return {"overall_labels_per_user": overall_labels_per_user,
            "aggregated_labels_per_user": aggregated_labels_per_user}


# ---- LITTLE HELPERS -------

def remove_other_annotations(df, entire_msg_group_only=False, threshold=4):
    df["is_other"] = df[["auto_generated", "spam", "corrupted"]].max(axis=1)
    msg_groups = df[["email_id", "is_other"]].groupby('email_id')
    droppable = []
    key = 1

    # 1.2 iterate over msg groups and remove groups were >4 were labeled as spam/auto-generated/corrupted ('other')
    for name, group in msg_groups:
        count_other = 0
        value_counts = group.is_other.value_counts()

        if key in value_counts:
            count_other = value_counts.loc[key]

        # if more than X (default: 4) raters say it's spam/auto-generated/corrupted remove whole msg
        if count_other > threshold:
            droppable_indices = group.index.tolist()
            droppable.extend(droppable_indices)

        # elif not the majority thinks it's OTHER, but those who think it is should be removed:
        elif not entire_msg_group_only:
            droppable_indices = group.index[group.is_other == 1].tolist()
            droppable.extend(droppable_indices)

        # else leave in nan values (this matters for computation of inter rater agreement)
        else:
            pass

    return df.drop(droppable)


def remove_unsure_annotations(df, threshold=3, replace_cols_w_NAN=[]):
    """
    removes unsure annotations if the number of "sure" annotations surpasses the given threshold
    :param df:
    :param threshold:
    :param replace_cols_w_NAN:
    :return:
    """
    msg_groups = df[["email_id", "not_sure"]].groupby('email_id')
    droppable = []
    key = 0  # key for the value counts, use key 0 to count when not_sure == 0

    for name, group in msg_groups:  # iterate over each msg group
        count_sure = 0  # keep track of the number of annotations where not_sure is 0
        value_counts = group.not_sure.value_counts()  # we count the differing values of 'not_sure'

        if key in value_counts:  # avoid key error, (would happen if all annotations were not sure == 1)
            count_sure = value_counts.loc[key]

        if count_sure > threshold:
            droppable_indices = group.index[group.not_sure == 1].tolist()
            droppable.extend(droppable_indices)
        else:
            pass  # nothing to do here

    if replace_cols_w_NAN:
        # replace label columns with nan for rows in droppable_indices
        # https://stackoverflow.com/questions/37725195/pandas-replace-values-based-on-index
        for col in replace_cols_w_NAN:
            df.loc[droppable, col] = np.nan

        return df

    else:
        return df.drop(droppable)  # ok, now let's drop the unsure ratings



