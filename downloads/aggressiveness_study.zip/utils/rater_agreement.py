import krippendorff
import numpy as np
import pandas as pd
from utils.label_mapping import get_labels_per_user
from rpy2.robjects import DataFrame, FloatVector, IntVector
from rpy2.robjects.packages import importr
import rpy2.rinterface_lib.callbacks as rinterface
from math import isclose


def get_krippendorffs_alphas(labels_per_user_dict):
    # 1. nominal
    overall_nominal = round(krippendorff.alpha(labels_per_user_dict["overall_labels_per_user"], level_of_measurement="nominal"), 6)
    aggregated_nominal = round(krippendorff.alpha(labels_per_user_dict["aggregated_labels_per_user"], level_of_measurement="nominal"), 6)

    # 2. ordinal
    overall_ordinal = krippendorff.alpha(labels_per_user_dict["overall_labels_per_user"], level_of_measurement="ordinal")
    aggregated_ordinal = round(krippendorff.alpha(labels_per_user_dict["aggregated_labels_per_user"], level_of_measurement="ordinal"),
                               6)
    # 3. interval
    overall_interval = round(krippendorff.alpha(labels_per_user_dict["overall_labels_per_user"], level_of_measurement="interval"), 6)
    aggregated_interval = round(krippendorff.alpha(labels_per_user_dict["aggregated_labels_per_user"], level_of_measurement="interval"), 6)

    # 4. ratio
    overall_ratio= round(krippendorff.alpha(labels_per_user_dict["overall_labels_per_user"], level_of_measurement="ratio"), 6)
    aggregated_ratio = round(krippendorff.alpha(labels_per_user_dict["aggregated_labels_per_user"], level_of_measurement="ratio"), 6)

    table_data = {
                    'nominal': [overall_nominal, aggregated_nominal], 
                    "ordinal": [overall_ordinal, aggregated_ordinal],
                    "interval": [overall_interval, aggregated_interval],
                    "ratio": [overall_ratio, aggregated_ratio]
                    }


    return pd.DataFrame.from_dict(table_data, orient='index', columns=['overall label', 'aggregated label'])


def get_iccs(labels_per_user_dict):
    """
    https://stackoverflow.com/a/48277559
    :param labels_per_user_dict:
    :return:
    """

    df_agg = get_icc_df(labels_per_user_dict["aggregated_labels_per_user"])
    df_over = get_icc_df(labels_per_user_dict["overall_labels_per_user"])

    # suppress spurious and verbose R warnings that cannot be fixed via rpy2
    storage = []
    def write_to_storage(x):
        storage.append(x)
    rinterface.consolewrite_warnerror = write_to_storage

    r_icc = importr("ICC")
    icc_res_over = r_icc.ICCbare("groups", "values", data=df_over)
    icc_res_agg = r_icc.ICCbare("groups", "values", data=df_agg)

    return pd.DataFrame({'ICC overall_label': [icc_res_over[0]], 'ICC aggregated_label': [icc_res_agg[0]]})


def get_icc_df(data):
    msg_nums = []
    values = []

    # for each e-mail:
    for i in range(len(data[0])):
        # for each user:
        for j in range(len(data)):
            # only handle existing values
            if not np.isnan(data[j][i]):

                # number e-mail from 1 to end
                msg_nums.append(i + 1)
                # add values
                values.append(data[j][i])

    df = DataFrame({"groups": IntVector(msg_nums),
                    "values": FloatVector(values)})
    return df


def calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users=[]):

    print("\nInter-Rater Agreement: multi-label, incl. unsure")
    labels_per_user = get_labels_per_user(df_single_labels, users, remove_unsure=False, binary_labels=False)
    print(get_iccs(labels_per_user))
    print(get_krippendorffs_alphas(labels_per_user))

    print("\nInter-Rater Agreement: binary, incl. unsure")
    labels_per_user = get_labels_per_user(df_single_labels, users, remove_unsure=False, binary_labels=True)
    print(get_iccs(labels_per_user))
    print(get_krippendorffs_alphas(labels_per_user))

    print("\nInter-Rater Agreement: multi-label, excl. unsure")
    labels_per_user = get_labels_per_user(df_single_labels, users, remove_unsure=True, binary_labels=False)
    print(get_iccs(labels_per_user))
    print(get_krippendorffs_alphas(labels_per_user))

    print("\nInter-Rater Agreement: binary, excl. unsure")
    labels_per_user = get_labels_per_user(df_single_labels, users, remove_unsure=True, binary_labels=True)
    print(get_iccs(labels_per_user))
    print(get_krippendorffs_alphas(labels_per_user))


"""

## USAGE
from utils.label_mapping import get_labels_per_user
from utils.rater_agreement import get_iccs, get_krippendorffs_alphas
import pandas as pd

path = "single_mapped_labels.csv"

df = pd.read_csv(path, sep=";")
labels_per_user = get_labels_per_user(df, [29,30,31,32], binary_labels=False)
get_iccs(labels_per_user)
get_krippendorffs_alphas(labels_per_user)
"""
