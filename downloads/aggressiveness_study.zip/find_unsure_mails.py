import os
import pandas as pd
import numpy as np
from utils.label_mapping import map_single_labels, remove_unsure_annotations, remove_other_annotations
pd.options.mode.chained_assignment = None

unsure_outfile = "unsure_emails.csv"

def read_and_process_annotated_mails(path):
    # Read the labelled table and remove mails marked as other.
    mapped_annotations_df = pd.read_csv(path, sep=",")
    mails = remove_other_annotations(mapped_annotations_df, entire_msg_group_only=False, threshold=4)  
    mails = remove_unsure_annotations(mails, threshold=-1)     

    return mails

def do_all_but_one_agree(df):
    # First check the length. Return True if too short, because then we don't count it.
    if len(df) <= 2:
        return False, 0, 0

    # Now transform the non-binary label to True for aggressive and False for not aggressive.
    # The previos labels are:
    # -3 - very aggressive      -> aggressive
    # -2 - mildly aggressive    -> aggressive
    #  1 - neutral              -> not aggressive
    #  2 - friendly             -> not aggressive
    df["overall_label"] = df.apply(lambda x : x["label"] < 0, axis = 1)

    # Check whether one of them occurs only once. 
    occurences = df[["email_id", "overall_label"]].groupby("overall_label").count().rename(columns={"email_id" : "occurences"})

    label_true_occurence = occurences["occurences"].min()
    label_false_occurence = occurences["occurences"].max()

    # If one of the labels occurs only once or not at all, then return True, else False.
    # If there is only one entry, return True as all ratings agreed.
    # Additionaly, return the number of votes, could be useful in further analysis.
    return ((len(occurences) == 1 or 
            min(label_false_occurence, label_true_occurence) == 1),
            label_true_occurence, 
            label_false_occurence)

def get_unsure_mail_ids(path):
    mails = read_and_process_annotated_mails(path)
    
    # Get the unique ids of all mails.
    ids = pd.unique(mails["email_id"])
    
    # Check each email seperately whether there is more than one person that disagrees with the rest.
    # If this is the case, add the msg_id to the resulting list.
    result = {}

    for id in list(ids):
        entries = mails[mails["email_id"] == id]
        agreement, number_aggressive, number_not_aggressive = do_all_but_one_agree(entries)
        if not agreement:
            result[id] = (number_aggressive, number_not_aggressive)

    return result
        
  
# Batch 1
path1 = "annotations_batch1.csv"
map_single_labels(path1, write_output=True, outfile="single_mapped_labels.csv")
r1 = get_unsure_mail_ids(path1)

# Batch 2
path2 = "annotations_batch2.csv"
map_single_labels(path2, write_output=True, outfile="single_mapped_labels2.csv")
r2 = get_unsure_mail_ids(path2)

# Concatenate the two dicts and extract the keys.
unsure_mails = {**r1, **r2}
only_unsure_ids = list(unsure_mails.keys())

print(f"There are {len(unsure_mails)} mails with disagreement of more than one person.")

all_mails = pd.concat([read_and_process_annotated_mails(path1), read_and_process_annotated_mails(path2)])[["email_id", "msg_id"]].groupby("msg_id").count().rename(columns={"email_id" : "ratings"}).reset_index()

unsure_df = all_mails[all_mails["msg_id"].isin(only_unsure_ids)]
unsure_df["agressive_votes"] = unsure_df.apply(lambda x : unsure_mails[x["msg_id"]][0], axis = 1)
unsure_df["not_agressive_votes"] = unsure_df.apply(lambda x : unsure_mails[x["msg_id"]][1], axis = 1)
# Rename first column to match the name of the column of the mail content data
unsure_df = unsure_df.rename(columns = {"msg_id" : "Message_id"})
unsure_df.to_csv(unsure_outfile, sep=',', index=False)
