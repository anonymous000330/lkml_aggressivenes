## Data collection

(1) Download the e-mails from the LKML using the tool nnt2mbox (https://github.com/xai/nntp2mbox/), e.g.:

``python3 nntp2mbox.py -u gmane.linux.kernel``

(2) Extract content and header from each e-mail, using the script "list-mbox.py":

To get the headers:

``python3 list_mbox.py gmane.linux.kernel.mbox -H``

To get the contents:
``python3 list_mbox.py  gmane.linux.kernel.mbox -C``


(3) Sample e-mails. We only provide a rough draft of the script (not executable, does not sample our e-mails) and not the complete script, as the actual sampling cannot be published do to data privacy (as it contains names of the e-mail authors for which we oversampled):

``Rscript sampleMailContent.R``

The therefrom resulting csv files contain the header information and the e-mails' contents, respectively.

## Data Preprocessing

To preprocess the data, we use multiple scripts. As they contain access to our database which stores non-anonymized information, we removed some of the parts for double-blindness es well as for data confidentiality, as there also some name preprocessing on real names was performed.

The script ``dictify.py'' reads the sampled e-mail data, formats, checks and removes names, and replaces citations by special tokens.

## E-Mail Rendering

In order to render the preprocessed e-mails for annotation (as can be seen on the screenshots), we use the following scripts:

``annotation.php`` renders the whole annotation page (as shown in Figure 1 in the paper).

``email.php`` renders one particular e-mail.

``style.css`` contains the formatting of the page.

``tokens.css`` contains the formatting of the special tokens (author removed, recipient removed, CC recipient removed, e-mail removed, URL removed, citation removed).

Notice that we demonstrate all the rendering scripts just for demonstration and replicability reasons. Unfortunately, for data privacy reasons, we had to exclude the connection to our database.











