<?php
include 'db.php';

$user = $_SESSION['user'];

function getUsersForEmail($host, $username, $password, $databasename, $email_id) {
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }
    $content = "";
    $sql = "SELECT user_id FROM annotations_v2 WHERE email_id =" . $email_id;
    $result = $link->query($sql);
    $rows = [];

    while($row = $result->fetch_array())
    {
        $rows[] = $row["user_id"];
    }

    $link->close();
    sort($rows);
    //<div id="subject"><?php echo $content; // load new email content
    return $rows;
}

function getEmailId($host,$username,$password, $databasename, $user){
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect" . mysqli_connect_error());
    }
    $email_id = -1;

    $sql = "SELECT emails.email_id FROM emails 
        LEFT JOIN annotations_v2 ON (annotations_v2.user_id = ". $user . " AND emails.email_id = annotations_v2.email_id) WHERE annotations_v2.email_id IS NULL LIMIT 1";

    $result = $link->query($sql);

    if ($result->num_rows > 0) {

        $row = $result->fetch_assoc();
        $email_id = $row["email_id"];

    }

    $link->close();
    return $email_id;
}

function getEmailContent($host,$username,$password, $databasename, $email_id){
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }
    $content = "";
    $sql = "SELECT content FROM emails WHERE email_id =" . $email_id;
    $result = $link->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $content = $row["content"];
        $content = "<div id=\"subject\">" . replace_tokens($content) . "</div>";


    } else {
        $content = "<div class='awesome'><h2>Awesome! Thank YOU &heartsuit;</h2><img src=\"happylinus.jpg\" alt=\"Wohoo!\"><br><h3>You have reached the bottom of the database.</h3></div>";
    }

    $link->close();
    //<div id="subject"><?php echo $content; // load new email content
    return $content;
}

function getPrev($host,$username,$password, $databasename, $user)
{
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if ($link->connect_error) {
        die("ERROR: could not connect at get Prev" . mysqli_connect_error());
    }

    $sql = "SELECT email_id FROM annotations_v2 WHERE user_id = ". $user;
    $result = $link->query($sql);

    if (!$result) {
        printf("Query failed: %s\n", $link->error);
        exit;
    }

    $rows = [];
    while($row = $result->fetch_assoc()) {
        $rows[]=$row["email_id"];
    }

    $link->close();
    return $rows;

}

function getAnnotation($host,$username,$password, $databasename, $user, $email_id) {
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }
    $label = 100;
    $sql = "SELECT label, target_recipient, target_thirdparty, target_technical, target_self, target_quoted, target_other, target_none, auto_generated, spam, corrupted, unsure, comment, meta_talk FROM annotations_v2 WHERE user_id = ". $user . " AND  email_id =" . $email_id;
    $result = $link->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $label = $row["label"];
        $target_recipient = $row["target_recipient"];
        $target_thirdparty = $row["target_thirdparty"];
        $target_technical = $row["target_technical"];
        $target_self = $row["target_self"];
        $target_quoted = $row["target_quoted"];
        $target_other = $row["target_other"];
        $target_none = $row["target_none"];
        $auto_generated = $row["auto_generated"];
        $spam = $row["spam"];
        $corrupted= $row["corrupted"];
        $unsure = $row["unsure"];
        $comment = $row["comment"];

        $meta = $row["meta_talk"];

        if (!$comment) { $comment = "";}
    }

    $link->close();

    return [
        "label" => $label,
        "target_recipient" => $target_recipient,
        "target_thirdparty" => $target_thirdparty,
        "target_technical" => $target_technical,
        "target_self" => $target_self,
        "target_quoted" => $target_quoted,
        "target_other" => $target_other,
        "target_none" => $target_none,
        "auto_generated" => $auto_generated,
        "spam" => $spam,
        "corrupted" =>  $corrupted,
        "unsure" => $unsure,
        "comment" => $comment,
        "meta_talk" => $meta,
    ];
}


function getCounterInfo($host,$username,$password, $databasename, $user) {
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }

    // get count of annotated emails for this $user
    $sql = "SELECT id FROM annotations_v2 WHERE user_id = ". $user;
    $result = $link->query($sql);
    $annotated = $result->num_rows;

    // get count of the total number of emails
    $sql = "SELECT email_id FROM emails";
    $result = $link->query($sql);
    $totalcount = $result->num_rows;

    $link->close();


    return [$annotated, $totalcount];
}




function replace_tokens($content) {

    $new_content = htmlentities($content);

    $tok_citation = "REPLY_CITATION_TOKEN";
    $tok_source_elem = "SOURCE_ELEM_TOKEN";
    $tok_email_addr = "EMAIL_ADDR_TOKEN";
    $tok_source_block = "CODESNIPPET_TOKEN";
    $tok_dev_name = "DEV_NAME_TOKEN";
    $tok_url = "WWW_URL_TOKEN";
    $tok_log = "LOGS_TOKEN";



    $tok_dev_sender_name = "EMAIL_SENDER_TOKEN";
    $tok_dev_to_name = "EMAIL_TO_RECIPIENT_TOKEN";
    $tok_dev_cc_name = "EMAIL_CC_RECIPIENT_TOKEN";

    $citation     = '<p     class="cite_reply">&gt;[citation] (removed)</p>';
    $source_elem  = '<span  class="source_elem">[source code ref]</span>';
    $email_addr   = '<span  class="email_addr">[email-address]</span>';
    $source_block = '<p     class="source_block">[source code block] (removed)</p>';
    $dev_name     = '<span  class="dev_name">[developer name]</span>';
    $url          = '<span  class="url">[ URL ]</span>';
    $log          = '<span  class="logs_block">[ LOG output (removed)]</span>';

    $dev_sender_name     = '<span  class="dev_name dev_sender_name">[Author of email]</span>';
    $dev_to_name     = '<span  class="dev_name">[Recipient of email]</span>';
    $dev_cc_name     = '<span  class="dev_name">[CC recipient]</span>';

    $new_content = str_replace($tok_citation, $citation, $new_content);
    $new_content = str_replace($tok_source_elem, $source_elem, $new_content);
    $new_content = str_replace($tok_source_block, $source_block, $new_content);
    $new_content = str_replace($tok_email_addr, $email_addr, $new_content);
    $new_content = str_replace($tok_dev_name, $dev_name, $new_content);
    $new_content = str_replace($tok_dev_sender_name, $dev_sender_name, $new_content);
    $new_content = str_replace($tok_dev_to_name, $dev_to_name, $new_content);
    $new_content = str_replace($tok_dev_cc_name, $dev_cc_name, $new_content);
    $new_content = str_replace($tok_url, $url, $new_content);
    $new_content = str_replace($tok_log, $log, $new_content);

    return $new_content;

}

// --- T U T O R I A L --- //

function getTutorialPos($host,$username,$password, $databasename, $user_id) {

    return 10;
}

function getAnnotatedEmailContent_Tutorial($host,$username,$password, $databasename, $email_id){
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }
    $label = 100;
    $sql = "SELECT content, content_annotated, label, target_recipient, target_thirdparty, target_technical, target_self, target_quoted, target_other, target_none, auto_generated, spam, corrupted, unsure, comment, meta_talk FROM emails_tutorial WHERE email_id =" . $email_id;
    $result = $link->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $content = $row["content"];
        $content_annotated = $row["content_annotated"];
        $label = $row["label"];
        $target_recipient = $row["target_recipient"];
        $target_thirdparty = $row["target_thirdparty"];
        $target_technical = $row["target_technical"];
        $target_self = $row["target_self"];
        $target_quoted = $row["target_quoted"];
        $target_other = $row["target_other"];
        $target_none = $row["target_none"];
        $auto_generated = $row["auto_generated"];
        $spam = $row["spam"];
        $corrupted= $row["corrupted"];
        $unsure = $row["unsure"];
        $comment = $row["comment"];

        $meta = $row["meta_talk"];

        if (!$comment) { $comment = "";}
    }

    $link->close();

    if ($content_annotated != "") {
        $content_annotated = "<div id=\"subject\">" . htmlspecialchars_decode(replace_tokens($content_annotated)) . "</div>";
    }

    return [
        "content" => "<div id=\"subject\">" . htmlspecialchars_decode(replace_tokens($content)) . "</div>",
        "content_annotated" => $content_annotated,
        "label" => $label,
        "target_recipient" => $target_recipient,
        "target_thirdparty" => $target_thirdparty,
        "target_technical" => $target_technical,
        "target_self" => $target_self,
        "target_quoted" => $target_quoted,
        "target_other" => $target_other,
        "target_none" => $target_none,
        "auto_generated" => $auto_generated,
        "spam" => $spam,
        "corrupted" =>  $corrupted,
        "unsure" => $unsure,
        "comment" => $comment,
        "meta_talk" => $meta,
    ];
}

function getCounterInfo_Tutorial($host,$username,$password, $databasename, $user) {
    $link = mysqli_init();
    #$link->options(MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, true);
    #$link->ssl_set(NULL, NULL, NULL, "/etc/ssl/certs/", NULL);
    $link->real_connect($host,$username,$password, $databasename);

    if($link->connect_error) {
        die("ERROR: could not connect " . mysqli_connect_error());
    }

    // get count of annotated emails for this $user
    $sql = "SELECT tutorial FROM users WHERE id = ". $user;
    $result = $link->query($sql);

    $tutorial_pos = 1;

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $tutorial_pos = $row["tutorial"];
    }

    // get count of the total number of emails
    $sql = "SELECT email_id FROM emails_tutorial";
    $result = $link->query($sql);
    $totalcount = $result->num_rows;

    $link->close();


    return [$tutorial_pos, $totalcount];
}

?>
