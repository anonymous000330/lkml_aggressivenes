<?php
include('auth.php');
if ($_SESSION['tutorial_pos'] < $_SESSION['tutorial_total']) {

    header('Location: tutorial.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AnTo - Annotation Tool</title>
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/tokens.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">
</head>
<body>
<?php

include 'email.php';
include 'GET_params.php';

$annotation_label = NULL;

if ($_SESSION['prev_idx'] == 0 || (count($_SESSION['prev_ids']) - $_SESSION['prev_idx']) < 0) { // prev_idx == 0 -> email not annotated, or navigated 'too far back'
    $_SESSION['email_id'] = getEmailId($host, $username, $password, $databasename, $_SESSION['user']);
} else { // email is annotated (user navigated to previous email), retrieve email_id and it's annotation value (annotation value is set in the form below)
    $_SESSION['email_id'] = $_SESSION['prev_ids'][(count($_SESSION['prev_ids']) - $_SESSION['prev_idx'])];

    $annotation = getAnnotation($host, $username, $password, $databasename, $_SESSION['user'], $_SESSION['email_id']);
    $annotation_label = intval($annotation["label"]);
    $annotation_target_recipient = intval($annotation["target_recipient"]);
    $annotation_target_thirdparty = intval($annotation["target_thirdparty"]);
    $annotation_target_technical = intval($annotation["target_technical"]);
    $annotation_target_self = intval($annotation["target_self"]);
    $annotation_target_quoted = intval($annotation["target_quoted"]);
    $annotation_target_other = intval($annotation["target_other"]);
    $annotation_target_none = intval($annotation["target_none"]);
    $annotation_auto_generated = intval($annotation["auto_generated"]);
    $annotation_spam = intval($annotation["spam"]);
    $annotation_corrupted = intval($annotation["corrupted"]);
    $annotation_unsure =  intval($annotation["unsure"]);
    $annotation_comment =  $annotation["comment"];
    $annotation_meta = intval($annotation["meta_talk"]);
}

$content = getEmailContent($host,$username,$password, $databasename, $_SESSION['email_id']);

?>

<?php include('guidelines.php'); ?>

<div id="wrapper">

    <!--    LEFT COLUMN: email content -->
    <div id="lcol">
        <!--    USER INFO (annotation count, user id, log out) -->
        <div id="user_info">

            <span id="user_logout" class="user_info"><a href="gdpr.php" target="_blank">GDPR</a>, annotator: <span class="username" title="your username"><?php echo $_SESSION['user_name'] ?></span> &nbsp;<span id="logout" onclick="location='logout.php'" title="log out">Quit</span></span>
            <span id="guidelines_btn" title="show/hide annotation guidelines">&#128712;&nbsp;&nbsp;&nbsp;guidelines</span>
            <?php if (($_SESSION['email_id'] !== -1)) { include('annotation_counter.php'); }?>


        </div>
        <?php echo $content; // load new email content ?><br>
    </div>

    <!--    RIGHT COLUMN: user info, label selection -->
    <div id="rcol">

        <!--    ANNOTATION: select a label -->
    <?php
    include "form_interface.php";
    ?>
    </div>
</div>

<script src="js/jquery-ui-1.12.1.custom/external/jquery/jquery.js"></script>
<script src="js/jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script type="text/javascript" src="js/form.js"></script>
</body>
</html>
