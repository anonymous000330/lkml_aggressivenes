import csv
from email.header import decode_header, make_header
from lkml_names import split_name
import pandas as pd
from first_names_db import clean_firstnames

# first run clean_firstnames
clean_firstnames()
# only after that open the firstnames_clean.csv !!

csv_first_names = pd.read_csv("firstnames_clean.csv", header=None)
# SOURCE first names https://github.com/MatthiasWinkelmann/firstname-database

first_names = set(csv_first_names[0])

ignore_ids = ["DT", "Info", "Information", "scsi", "usb", "mm", "arch", "DVB ML", "IA64", "4.5", "15Hz", "HPA", "misc",
              "LLVMdev", "LMOL", "LSE", "LSM", "LTP", "LTT", "LTT-Dev", "LVM", "LWN", "Mail List", "Lazy", "MMC List",
              "Mailinglist", "MTD", "Lx", "CE", "CE Linux Developers List", "RT", "RTC", "RVK", "RTAI users", "RSBAC",
              "CGL Discussion", "CGNL", "CPGS", "CRYPTO API", "CSA-ML", "KVM", "GIT", "GCC", "GDB Patches", "Autofs",
              "Auto QA", "DTKERNEL"]
ignore_names = ["fs", "x86", "stable", "Trivial", "trivial", "device"]


# IMPORTANT NOTE: when using newer data sets, we must UPDATE the names list to include new contributors!

def fix_lkml_names():
    with open("names.csv", 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        rows = []

        ids = []  # solely for documentation of added names

        for row in reader:
            if row["id"] in ignore_ids:  # remove rows where name is linux, usb, kernel; remove where id is DT, Information
                continue

            if row["name"] in ignore_names:
                continue

            if row["id"] not in ids:
                ids.append(row["id"])

            new_name = sanitize_name(row["name"])
            if new_name is None:    # ignore invalid names
                continue

            r = [row['id'], new_name.lstrip().rstrip().lower()]
            if r not in rows:

                rows.append(r)

        rows.extend(get_DT_names())

        ids.extend(["DT", "HPA"])

        # add valid first names

        added_valid_names = []
        for i in ids:
            names = [r[1] for r in rows if r[0] == i]
            valid_names = get_first_name_rows(names)

            for valid_name in valid_names:
                row = [i, valid_name]

                if row not in rows:
                    rows.append(row)
                    added_valid_names.append(row)  # solely for documentation of added names

        # sort rows by Id name by length - longest (1. most tokens, 2. string length) first!
        sorted_rows = sorted(rows, key=lambda row: (row[0], len(split_name(row[1])) * -1, len(row[1]) * -1))
        rows = [["id", "name"]] + sorted_rows

        newf = open("new_names.csv", "w", newline="\n")
        writer = csv.writer(newf)
        for row in rows:
            writer.writerow(row)
        newf.close()

        # --- solely for documentation of added names
        with open("added_names.csv", 'w') as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerows(added_valid_names)
        # -----


def sanitize_name(name):
    """
    returns an array with the sanitized name or an empty array if the input does not contain alphabetical chars
    :param name:
    :return:
    """
    if any(c.isalpha() for c in name):  # check if name contains any alphabetical characters
        # deal with email header encoding
        name = decode_email_name(name)
        return name
    else:
        return None


def decode_email_name(name):
    try:
        new_name = str(make_header(decode_header(name)))
        if new_name == "":
            new_name = None
        return new_name
    except:
        return None



def get_first_name_rows(names):

    # 1. get n-grams of the names, put them in a list
    ngrams = []

    for name in names:

        unigrams = name.split()

        if len(unigrams) < 2: 
            continue

        bigrams = [" ".join(unigrams[i:i+2]) for i in range(len(unigrams) - 1)]

        ngrams.extend(unigrams)
        ngrams.extend(bigrams)

    # 2. turn the list of n-grams into a set
    ngrams = set(ngrams)

    # filter out the names that are valid
    valid_names = ngrams.intersection(first_names)

    return list(valid_names)




def get_DT_names():
    # This is a list of manually selected names from the original names.csv for the id 'DT'.
    # Since this id is mostly associated with concepts rather than people (e.g., usb, linux,
    # virtual,...) we first excluded it entirely from the new_names list. As there are in fact 
    # a few people associated with this specific id (most important example is Mauro Carvalho 
    # Chehab), we manually picked those that referred to a person.
    # 
    DT_people = """DT,bla""" # actual names are removed for data privacy reasons

    rows = DT_people.split("\n")
    #names = [row.split(",") for row in rows]
    names = []
    for row in rows:
        r = row.split(",")
        new_row = [r[0], sanitize_name(r[1]).lstrip().rstrip().lower()]
        if new_row not in names and new_row[1] is not None:
            names.append(new_row)

    return names
    

#fix_lkml_names()


