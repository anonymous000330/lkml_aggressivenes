#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public
# License v2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public
# License along with this program; if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 021110-1307, USA.

import argparse
import csv
import email
import mailbox
import re
from typing import *

import unicodedata
from ftfy import fix_encoding
from email.header import decode_header, make_header

import dateutil.parser
import dateutil.tz
from tqdm import tqdm

cols = [
    'From_name',
    'From_email',
    'Message-Id',
    'Date',
    'Date_offset',
    'Subject',
    'Thread-Id',
    'To',
    'Cc',
]

__EMAIL_PATTERN = re.compile("\\S+@\\S+")

__INTERNAL_DELIMITER = ","
__REMOVABLE_CHARACTERS_WHITESPACE = ["\t", "\n", "\r"]
__REMOVABLE_CHARACTERS_PUNCTUATION = ["\"", ",", ";", "\\(", "\\)", "'", "\\"]
__REMOVABLE_CHARACTERS = [__INTERNAL_DELIMITER] + __REMOVABLE_CHARACTERS_WHITESPACE + __REMOVABLE_CHARACTERS_PUNCTUATION


def remove_symbols(input_string: str, symbols=__REMOVABLE_CHARACTERS, replace_char="") -> str:
    """Remove the symbols listed in __REMOVABLE_SYMBOLS from the input string and replace them with the symbol given by replace_char.
    Additionally, removes trailing whitespace.

    :param input_string: the string to remove the symbols from
    :param symbols: the symbols/characters to remove from the input string (default: __REMOVABLE_CHARACTERS)
    :param replace_char: the symbol to insert for any removed symbol
    :return: the stripped input string with all removed symbols replaced with 'replace_char'
    """
    for needle in symbols:
        input_string = input_string.replace(needle, replace_char)

    return input_string.strip()


def fix_name_encoding(name):
    """
    Fix encoding of names (originating from e-mail headers).
    :param name: expects a name string extracted from the database
    :return: correctly encoded string of the name
    """

    # find out character set of the encoded name
    info = decode_header(name)

    try:
        # Apply correct encoding
        return str(make_header(info))
    except UnicodeDecodeError:
        # Applying correct encoding did not work, return string as is
        return name
    except LookupError:
        # Encoding not found, return string as is
        return name
    return name


def get_name_mail_pairs(mail_string: str) -> str:
    #return email.utils.getaddresses([mail_string.replace('\\"', '')])
    return email.utils.getaddresses([re.sub(r'\\\"','', mail_string)])


def tidy_name_mail_pair(name_and_mail: Tuple[str, str]) -> Tuple[str, str]:
    name, mail = name_and_mail

    # preprocessing
    mail = mail.lower()

    # if name is not given, use e-mail prefix
    if name == '':
        name = mail #.split('@')[0]

    # remove problematic characters
    name = remove_symbols(name)
    mail = remove_symbols(mail)

    # trim trailing and leading whitespace
    name = fix_name_encoding(name.strip())
    mail = mail.strip()

    ## if name looks like an email address, use only local part as name
    #if __EMAIL_PATTERN.match(name):
    #    name = name[:name.index("@")]

    return name, mail


def format_name_mail_pair(name_and_mail: Tuple[str, str]) -> str:
    """
    :param name_and_mail: (name, mail) tuple
    :return: string with following format:
            name <mail>
    """

    name, mail = tidy_name_mail_pair(name_and_mail)
    #print(name, mail)
    if name == "":
        # This is the case if we have 'Undisclosed recipients:;", where 'name' is '' and 'mail' is ''
        print(mail)
        return ""
    else:
        return "\"%s\" <%s>" % (name, mail)


def format_mail_string(mail_string: str) -> str:
    """
    :param mail_string: string containing (multiple) names and/or email-addresses, like
        Aleksey Makarov <amakarov@ru.mvista.com>, max@mustermann.de (Max Mustermann)
    :return: re-formatted string with all name-mail pairs in the same format separated by the internal_delimiter,
             and the number of identifierd name-mail pairs
    """
    if mail_string is None:
        return ""
    else:
        formatted_names = list(map(format_name_mail_pair, get_name_mail_pairs(mail_string)))
        formatted_names = [entry for entry in formatted_names if entry is not ""]
        return __INTERNAL_DELIMITER.join(formatted_names)


def parse_date(date_string: str) -> Tuple[Optional[str], int]:
    """
    Reformat date string and remove timezone
    :param date_string: timestamp in unspecified format
    :return: a two-item str tuple with the following items:
                0- timestamp in format "%Y-%m-%d %H:%M:%S" (equal to "%F %T") and in UTC time
                1- the timezone offset of the original date in format "%z"
    """
    try:
        date = email.utils.parsedate_to_datetime(date_string)
    except TypeError:
        # Try different parsing method
        try:
            date = dateutil.parser.parse(date_string)
        except (ValueError, TypeError):
            if date_string:
                tqdm.write("Could not parse date: " + date_string)
            else:
                tqdm.write("Date not existing")
            return None, 0
    # Set timezone to UTC
    # This command must not be execute if there is no timezone information as datetime would use the local time and
    # subtract one hour.
    if date.tzinfo is not None:
        date_offset = int(date.strftime("%z"))
        date = date.astimezone(dateutil.tz.gettz('UTC'))
    else:
        date_offset = 0

    return date.strftime("%F %T"), date_offset


def identify_thread_ids(mbox: List[mailbox.mboxMessage]) -> dict:
    """Compute thread IDs and thread depth (based on heuristics).

    The algorithm is taken from the R package 'tm.plugin.mail' [1] and has been adapted to Python. The idea for the
    algorithm is taken from Jamie Zawinski <jwz@jwz.org> [2]. Basically, the algorithm uses RFC 2822 $3.6.4. as
    a basis.

    [1] https://github.com/wolfgangmauerer/tm-plugin-mail/blob/31e9ca1dc50087314c24ece95f2264f81c/pkg/R/mail.R#L104-L175
    [2] https://www.jwz.org/doc/threading.html

    :param mbox: The parsed mbox to identify threads on
    :return: a dict with message IDs mapped to a int tuple (thread IDs, thread depth)
    """

    # hash table storing (thread ID, thread level) for a given message ID
    cache = dict()

    def get_thread_id(parent: str) -> tuple:
        """Retrieve cached thread ID and thread level of parent (message ID) from cache.

        :param parent: a message ID to search for in table
        :return: a tuple (thread ID, thread level)
        """

        # default values
        thread_id = None  # no thread existing
        thread_level = 2  # there is already a previous message, when we come here

        if parent and len(parent) > 0 and parent in cache:

            # if we have a thread ID for the parent already, we return it
            if cache[parent][0]:
                thread_id = cache[parent][0]

            # if we have a thread level for the parent already, we return it
            if cache[parent][0]:
                thread_level = cache[parent][1]

        return thread_id, thread_level

    # starting thread ID
    tid = 1

    # perform thread identification for each message:
    for i, message in tqdm(enumerate(mbox)):
        # 1) get message ID
        message_id = message.get('Message-Id')

        # 2) get parents and references:
        # 2.1) get parent IDs
        parent_ids = message.get('In-Reply-To')
        if parent_ids:
            print('In-Reply-To: %s' % parent_ids)
            pattern = re.compile(r"<(\S+)>")
            parent_ids = [re.search(pattern, x).group(1) for x in filter(pattern.findall, str(parent_ids).split(", "))]
            print(parent_ids)
            parent_ids = email.utils.getaddresses(parent_ids)  # this can be a whitespace-separated list
            # remove first item of tuples and make them message IDs again
            parent_ids = ["<" + address + ">" for (_, address) in parent_ids]
        else:
            parent_ids = []
        # 2.2) get references
        ref_ids = str(message.get('References'))
        print('References: %s' % ref_ids)
        if ref_ids:
            ref_ids = email.utils.getaddresses([ref_ids])  # this can be a whitespace-separated list
            # remove first item of tuples and make them message IDs again
            ref_ids = ["<" + address + ">" for (_, address) in ref_ids]
            # reverse list of references (first one will be newest then, see RFC 2822 $3.6.4)
            ref_ids = list(reversed(ref_ids))
        else:
            ref_ids = []

        # 3) compute thread ID for current message:
        # 3.1) generate new thread if no parent and no references exist
        if not parent_ids and not ref_ids:
            cache[message_id] = (tid, 1)
            tid = tid + 1

        # 3.2) otherwise, use existing thread based on parents and references
        else:
            # 3.2.1) check parents if one is in a thread already
            for parent_id in parent_ids:
                parent_thread_id, parent_thread_level = get_thread_id(parent_id)
                if parent_thread_id:
                    # we have found a thread ID for one parent, so use it!
                    cache[message_id] = (parent_thread_id, parent_thread_level + 1)
                    # done; go to next message
                    break
            # 3.2.2) otherwise, check references if one is in a thread already
            else:
                for ref_id in ref_ids:
                    ref_thread_id, ref_thread_level = get_thread_id(ref_id)
                    # if we found a valid reference, break – this works as the
                    if ref_thread_id:
                        cache[message_id] = (ref_thread_id, ref_thread_level + 1)
                        break
                else:
                    # the message is a reply to some other message, but the parent
                    # e-mail is not available -- for instance, it could be a follow-up
                    # to a discussion from a separate mailing list. Anyway, create a new thread.
                    cache[message_id] = (tid, 1)
                    tid = tid + 1

    return cache


def process_mbox_file(mbox_file_name: str, dump_message_content, dump_meta_data):
    """

    :param mbox_file_name: filename of the mbox file
    :return:
    """
    mbox = mailbox.mbox(mbox_file_name)

    # sort mbox by date (messages with no date are sorted last)
    def sort_messages(msg):
        msg_date = msg.get('Date')
        msg_date_parsed = parse_date(msg_date)
        return msg_date is None, msg_date_parsed[0] if msg_date is not None else None

    mbox = sorted(mbox, key=sort_messages)

    # print message content to separate csv file
    if dump_message_content:
        print('Dump message content.')
        contents = []

        for message in tqdm(mbox):
            content = []
            content.append(message.get('Message-Id'))

            if not message.is_multipart():
                #tqdm(message.get('Message-Id'))
                print("## 1 ##")
                if (not message.get('Robot-Id') is None) or (not message.get('Git-Commit-Id') is None):
                    print("### Automatic e-mail omitted: " + message.get('Message-Id'))
                    final_content = ""
                else:
                    if not message.get('Content-Transfer-Encoding') is None:
                        try:
                            complete_content = message.get_payload(decode=True).decode('utf-8', 'ignore')
                        except:
                            tqdm.write("### Exception in " + message.get('Message-Id'))
                            complete_content = "" #message.get_payload(decode=False)

                    else:
                        complete_content = message.get_payload()

                    split_content = re.split("\n--", complete_content)
                    if len(split_content) > 1:
                        final_content = "\n"
                        for split_part in split_content:
                            if "\nSigned-off-by" in split_part or "\ndiff -" in split_part or "\n@@" in split_part:
                                continue
                            else:
                                final_content = split_part
                                break
                        if final_content == "\n" or not re.search('[a-zA-Z]{5,}', final_content):
                            print("### E-Mail only containing commit message omitted: " + message.get('Message-Id'))
                            final_content = ""
                    elif ((not "\nSigned-off-by" in split_content) and (not "\ndiff -" in split_content)
                            and (not "\n@@" in split_content)):
                        final_content = split_content[0]
                    else:
                        print("### E-Mail only containing commit message omitted: " + message.get('Message-Id'))
                        final_content = ""

                content.append(final_content) #.split("^---",1)[0])
            else:
                parts = ''
                print("## 2 ##")
                if (not message.get('Robot-Id') is None) or (not message.get('Git-Commit-Id') is None):
                    print("### Automatic e-mail omitted: " + message.get('Message-Id'))
                    final_content = ""
                    print("## 2.1 ##")
                else:
                    for part in message.walk():
                        if not part.get('Content-Disposition') is None:
                            if ('filename' in str(part.get('Content-Dispostion'))
                                    or 'name' in str(part.get('Content-Type'))
                                    or 'attachment' in str(part.get('Content-Disposition'))):
                                print("## 2.2 ##")
                                continue
                        if part.get_content_type() == 'text/plain':
                            print("## 2.3 ##")
                            try:
                                parts += part.get_payload(decode=True).decode('utf-8', 'ignore') + '\n'
                            except:
                                tqdm.write("#### Exception in " + message.get('Message-Id'))
                                parts += ""

                    split_content = re.split("\n--", parts)
                    if len(split_content) > 1:
                        print("## 2.4 ##")
                        final_content = "\n"
                        for split_part in split_content:
                            if "\nSigned-off-by" in split_part or "\ndiff -" in split_part or "\n@@" in split_part:
                                print("## 2.5 ##")
                                continue
                            else:
                                final_content = split_part
                                print("## 2.6 ##")
                                break
                        if final_content == "\n" or not re.search('[a-zA-Z]{5,}', final_content):
                            print("### E-Mail only containing commit message omitted: " + message.get('Message-Id'))
                            final_content = ""
                            print("## 2.7 ##")
                    elif ((not "\nSigned-off-by" in split_content) and (not "\ndiff -" in split_content)
                            and (not "\n@@" in split_content)):
                        final_content = split_content[0]
                        print("## 2.8 ##")
                    else:
                        print("### E-Mail only containing commit message omitted: " + message.get('Message-Id'))
                        final_content = ""
                        print("## 2.9 ##")
                if 'Here are a bunch more USB patches against your latest git tree.' in final_content:
                    print("++++++++++  " + message.get('Message-Id'))
                content.append(final_content) 
                print("## 3 ##")

            contents.append(content)

        header = [
            'Message-Id',
            'Content'
        ]

        output_file = mbox_file_name + "_2019-02-14_content.csv"
        with open(output_file, 'w') as csv_file:
            wr = csv.writer(csv_file, delimiter=';', lineterminator='\n', quoting=csv.QUOTE_NONNUMERIC)
            # Write header
            wr.writerow(header)

            for content in contents:
                wr.writerow(content)

    if dump_meta_data:
        print('Dump meta data (From, To, Cc, Date, Subject, Thread, ...)')

        # identify thread ID for each message
        thread_ids = identify_thread_ids(mbox)

        rows = []
        for message in tqdm(mbox):
            # Parse 'Date', 'MessageId' and 'Subject'
            row = []

            # Parse 'From' to 'From_name' and 'From_email'
            m_from = str(message.get('From'))
            if m_from is not None:
                address_list = get_name_mail_pairs(m_from)
                if len(address_list) > 1:
                    tqdm.write("WARNING: multiple sender in following mail: "
                               + str(message.get('Message-Id')) + ": " + m_from)
                from_name, from_email = tidy_name_mail_pair(address_list[0])
                row.append(from_name)
                row.append(from_email)
            else:
                tqdm.write("WARNING: from is None in following mail: " + message.get('Message-Id'))
                row += [None, None, None, None]

            # fetch message date and offset
            message_date, message_date_offset = parse_date(message.get('Date'))
            # fetch subject (casting with "str()" due to potential 'Header' class)
            message_subject = remove_symbols(str(message.get('Subject')), __REMOVABLE_CHARACTERS_WHITESPACE, " ")

            # add default columns
            row = row + [
                message.get('Message-Id'),  # message ID
                message_date,  # date
                message_date_offset,  # date offset
                message_subject,  # subject
                thread_ids[message.get('Message-Id')][0]  # thread ID
            ]

            # Override 'To' with 'Original-To'
            if not message.get("To"):
                del message["To"]
                message["To"] = message.get("Original-To")

            # Parse 'To' and 'Cc'
            for col in map(message.get, ['To', 'Cc']):
                if col is None:
                    row.append(None)
                else:
                    row.append(format_mail_string(str(col)))

            rows.append(row)

        # write output file
        output_file = mbox_file_name + ".csv"
        with open(output_file, 'w') as csv_file:
            wr = csv.writer(csv_file, delimiter=';', lineterminator='\n', quoting=csv.QUOTE_NONNUMERIC)
            # Write header
            wr.writerow(cols)

            for row in rows:
                wr.writerow(row)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mailboxes", default=[], nargs="+")
    parser.add_argument('-C', '--content', action='store_true')
    parser.add_argument('-H', '--header', action='store_true')
    args = parser.parse_args()
    content = args.content
    header = args.header

    # support multiple mbox files
    for mbox_file in args.mailboxes:
        process_mbox_file(mbox_file, content, header)
