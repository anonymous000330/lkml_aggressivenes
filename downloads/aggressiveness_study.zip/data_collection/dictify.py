import csv
import sys
import mysql.connector
import re

from lkml_names import remove_names


# FIRST, make sure the names list are clean and fixed
# (uncomment next 2 lines, if names list needs to be updated; takes a looong time) last cleanup: 21 May 2019
#from fix_lkml_names import fix_lkml_names
#fix_lkml_names()

#shilpa code
re_citation_group = re.compile(r'(REPLY_CITATION_TOKEN)+')


re_citation = re.compile(r'^(?:>+[^>\n]*\n*(?=>))*>+[^>\n]*?(?:$)(?!>)', re.MULTILINE)
# The dot is for file names.
re_src_code = re.compile(r'_*[a-zA-Z0-9]+(?:_(?!TOKEN)[a-zA-Z0-9]+)+(?:\.\w?|\(\))?')
re_email = re.compile(r'<?[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+>?')
re_url = re.compile(r'\w+://\w+\.[-_\w]+\/?[\.\?=#/\w\-_~&]*')

re_leading_spaces = re.compile(r'^[ \t]+', re.MULTILINE)  # replaced \s with [ t] to keep newline chars
re_trailing_spaces = re.compile(r'[ \t]+$', re.MULTILINE)  # replaced \s with [ t] to keep newline chars

re_srccode_lines_startswith = re.compile(r'^(?:@@|if \(|switch|case|for \(|#include|#define|struct|static|int \w+(?:.*)\s?{|void \w+(?:.*)\s?{|{).*$', re.MULTILINE)
re_srccode_lines_endswith = re.compile(r'^.*(?:{|}|;|\+\-)$', re.MULTILINE)
re_comments = re.compile(r'/\*[^*]*\*+(?:[^/*][^*]*\*+)*/')
re_dup = re.compile(r'^([A-Z]+_TOKEN)(\n\1)+$', re.MULTILINE)
# For lines starting with '+'
re_plus_minus = re.compile(r'^(\+|\->|\-)(.*)$', re.MULTILINE)
# For lines with '//'
re_single_line_comments = re.compile(r'(//.*)$', re.MULTILINE)
# For lines starting with '['
re_logs_crash = re.compile(r'^\[(?:.*)$', re.MULTILINE)
# end of Shilpas code

re_unify_codesnippetblocks = re.compile(r'CODESNIPPET_TOKEN(\s+CODESNIPPET_TOKEN)+', re.MULTILINE)

#re_unsubscribe = re.compile(r'To unsubscribe from this list:\ssend\sthe\sline\s["].+?["]\sin\sthe\sbody\sof\sa\smessage\sto\s+EMAIL_ADDR_TOKEN\sMore\smajordomo\sinfo\sat\s+WWW_URL_TOKEN', re.MULTILINE)
re_unsubscribe = re.compile(r'To unsubscribe from this list:\ssend\sthe\sline\s["].+?["]\sin\sthe\sbody\sof\sa\smessage\sto\s+EMAIL_ADDR_TOKEN\sMore\smajordomo\sinfo\sat\s+WWW_URL_TOKEN(\nPlease\sread\sthe\sFAQ\sat\s+WWW_URL_TOKEN){0,1}', re.MULTILINE)


def main():
    message_file = sys.argv[1]
    meta_file = sys.argv[2]
    if len(sys.argv) == 3:
        replace_flag = False
    else:
        replace_flag = bool(sys.argv[3])

    message_dict = {}

    with open(message_file, 'r', encoding="utf8") as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            content = row["Content"]
            if content == '':
                continue
            message_dict[row['Message_Id']] = {}
            message_dict[row['Message_Id']]["Content"] = preprocess(content)

    with open(meta_file, 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            if row['Message_Id'] not in message_dict.keys():
                print(row['Message_Id'])
                continue
            for key in row.keys():
                if key == "Message_Id":
                    continue
                message_dict[row['Message_Id']][key] = row[key]

    insert_data(message_dict, replace_flag)
    pass


def preprocess(content):

    new_content = content.lstrip()  # strip potential whitespace at beginning of email
    new_content = remove_leading_spaces(new_content)
    cite_match, new_content = find_sub_citations(new_content)
    #dicts['Citation_block'] = cite_match
    email_match, new_content = find_sub_email_ids(new_content)
    #dicts['Emails'] = email_match
    url_match, new_content = find_sub_url(new_content)
    #dicts['URLs'] = url_match
    #logs_match, new_content = find_sub_logs(new_content)
    #dicts['Logs'] = logs_match
    new_content = remove_conseq_dup_tokens(new_content)
    #
    #
    # Start of finding source code lines. First remove leading spaces in all lines
    #
    #
    new_content = re_unsubscribe.sub("", new_content)  # remove generic to unsubscribe text
    new_content = new_content.rstrip()

    return new_content

# shilpa start
def remove_leading_spaces(Content):
    Content = re_leading_spaces.sub('', Content)
    return(Content)

def remove_trailing_spaces(Content):
    Content = re_trailing_spaces.sub('', Content)
    return(Content)

def remove_conseq_dup_tokens(Content):
    Content = re_dup.sub(r'\1', Content)
    return(Content)

def find_sub_citations(Content):
    cite_match = re_citation.findall(Content)
    Content = re_citation.sub('REPLY_CITATION_TOKEN', Content)
    return(cite_match, Content)

def find_sub_email_ids(Content):
    email_match = re_email.findall(Content)
    Content = re_email.sub('EMAIL_ADDR_TOKEN', Content)
    return(email_match, Content)

def find_sub_url(Content):
    url_match = re_url.findall(Content)
    Content = re_url.sub('WWW_URL_TOKEN', Content)
    return(url_match, Content)

def find_sub_logs(Content):
    logs_match = re_logs_crash.findall(Content)
    Content = re_logs_crash.sub('LOGS_TOKEN', Content)
    return(logs_match, Content)

def remove_leading_plus_minus(Content):
    Content = re_plus_minus.sub(r'\2', Content)
    return(Content)

def find_sub_multiline_comments(Content):
    comments_match = re_comments.findall(Content)
    #Content = re_comments.sub('COMMENT_TOKEN',Content)
    Content = re_comments.sub('', Content)
    return(comments_match, Content)

def find_sub_single_line_comments(Content):
    comments_match = re_single_line_comments.findall(Content)
    #Content = re_single_line_comments.sub(r'\1 COMMENT_TOKEN',Content)
    Content = re_single_line_comments.sub('', Content)
    return(comments_match, Content)

def find_sub_code_snippets(Content):
    code_line_match = re_srccode_lines_startswith.findall(Content)
    Content = re_srccode_lines_startswith.sub('CODESNIPPET_TOKEN', Content)
    code_line_match.extend(re_srccode_lines_endswith.findall(Content))
    Content = re_srccode_lines_endswith.sub('CODESNIPPET_TOKEN', Content)
    return(code_line_match, Content)

# shilpa end





if __name__ == "__main__":
    main()



