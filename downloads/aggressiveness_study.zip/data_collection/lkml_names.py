import re
import csv


 file each time...)
def remove_names(content, from_id, from_name, to_ids, cc_ids):
    """

    :param content: string
    :param from_id: string
    :param from_name: string
    :param to_ids: array containing strings
    :param cc_ids: array containing strings
    :return: string

    """
    cc_ids = cc_ids.split(", ")
    to_ids = to_ids.split(", ")

    from_names = [from_name]
    to_names = []
    cc_names = []

    # read in names:
    with open("new_names.csv", 'r') as file:
        reader = csv.DictReader(file, delimiter=',')
        for row in reader:
            if row["id"] == from_id:
                from_names.append(row["name"])
            if row["id"] in to_ids:
                to_names.append(row["name"])
            if row["id"] in cc_ids:
                cc_names.append(row["name"])

    """
    Splittling the from_name works well with actual names, but will definitely cause problems if the from_name
    contains common English words (e.g., "file", "trivial") or specific terms (e.g., "x86", "debian");
    currently deemed unsafe to use    """
    # from_names.extend(split_name(from_name))  # use each word in the from_name as a name too


    new_content = content
    for name in from_names:
        new_content = find_and_replace_name(new_content, name, "EMAIL_SENDER_TOKEN")

    for name in to_names:
        new_content = find_and_replace_name(new_content, name, "EMAIL_TO_RECIPIENT_TOKEN")

    for name in cc_names:
        new_content = find_and_replace_name(new_content, name, "EMAIL_CC_RECIPIENT_TOKEN")

    return new_content


def split_name(name):
    """
    splits the given name into tokens, omits tokens that do not contain alphabetical characters

    :param name:
    :return:
    """
    tokens = [token for token in name.split() if any(c.isalpha() for c in token)]
    return tokens


def find_and_replace_name(text, name, replacement):
    """
    replaces each occurence of name in a text with the given replacement
    use regex to define word boundaries and ignore case
    :param text: string
    :param name: string
    :param replacement: string
    :return: string
    """

    """
    if the given name string ends with an escaped character (e.g. "Joshua C.") then the original regex won't match
    because technically word boundary ("\b") does not apply, so it is not fully replaced. Same goes for the 
    name string that starts with an escaped character.
    
    the current solution only takes care of strings that end wih a period
    """
    if name[-1] == ".":
        pattern = "".join([r"\b", re.escape(name), r"(\s|$)"])
        replacement += " "  # add a blank space, because the pattern above will 'eat' it.
    else:
        # original pattern that works for strings that don't start/end with a non-alphanumerical character
        pattern = "".join([r"\b", re.escape(name), r"\b"])

    try:
        new_text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    except:
        new_text = text

    return new_text


