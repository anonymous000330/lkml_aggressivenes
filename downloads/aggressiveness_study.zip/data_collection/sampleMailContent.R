options(stringsAsFactors = FALSE)

input.file.content = "gmane.linux.kernel-complete.mbox_2019-02-14_content.csv"
input.file.header = "mail_preprocessed.csv"
output.file.content = "linux-kernel-sampled-content_batch2_2019-10-18.csv"
output.file.header = "linux-kernel-sampled-header_batch2_2019-10-18.csv"

## Read mail data
cat("## Read mail data", fill = TRUE)

mail.contents <- read.csv(input.file.content, sep=";")
mail.headers <- read.csv(input.file.header, sep=",")

colnames(mail.contents) <- c("Message_Id", "Content")

cat("## Read previous sample", fill = TRUE)
previous.sample.header <- read.csv(previous.sample.header, sep=",")
previous.sampled.messageIds <- previous.sample.header[["Message_Id"]]

## Preprocess mail data: Remove mails with empty content
cat("## Preprocess mail data: Remove mails with empty content", fill =TRUE)

empty.contents <- mail.contents[(mail.contents[["Content"]]=="" | mail.contents[["Content"]]=="\n"),]
empty.contents.message.ids <- empty.contents[["Message_Id"]]

mail.contents <- mail.contents[!(mail.contents[["Message_Id"]] %in% empty.contents.message.ids),]
mail.headers <- mail.headers[!(mail.headers[["Message_Id"]] %in% empty.contents.message.ids),]

mail.contents <- mail.contents[!(mail.contents[["Message_Id"]] %in% t(mails.to.filter)),]
mail.headers <- mail.headers[!(mail.headers[["Message_Id"]] %in% t(mails.to.filter)),]

## Preprocess mail data: Remove mails which initiate a thread
cat("## Preprocess mail data: Remove mails which initiate a thread", fill = TRUE)

mail.headers <- mail.headers[mail.headers[["Is_initial_mail"]]=="FALSE",]
mail.headers.ids <- mail.headers[["Message_Id"]]
mail.contents <- mail.contents[mail.contents[["Message_Id"]] %in% mail.headers.ids,]

## Get variables used for sampling
cat("## Get variables used for sampling", fill = TRUE)

## THIS IS ONLY A TEMPLATE EXAMPLE, NOT THE ACTUAL SAMPLING

author1 <- "author1"
mails.author1 <- mail.headers[mail.headers[["From_Id"]] == author1,]

## Perform sampling
cat("## Perform sampling", fill = TRUE)

p2 <- sample(mails.author1[["Message_Id"]], 360, replace=FALSE)

sampled.mail.contents <- mail.contents[mail.contents[["Message_Id"]] %in% p1,]
s <- sample(p2, 360, replace=FALSE)
sampled.mail.contents <- sampled.mail.contents[match(s,sampled.mail.contents$Message_Id),]

sampled.mail.headers <- mail.headers[mail.headers[["Message_Id"]] %in% sampled.mail.contents[["Message_Id"]],]
sampled.mail.headers <- sampled.mail.headers[match(s, sampled.mail.headers$Message_Id),]

## Write sampled mail contents
cat("## Write sampled mail contents", fill = TRUE)

write.csv(sampled.mail.contents, file=output.file.content, row.names = FALSE)
write.csv(sampled.mail.headers, file=output.file.header, row.names = FALSE)



