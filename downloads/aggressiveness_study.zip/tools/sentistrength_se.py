import pandas as pd
import csv

from sklearn import metrics

# HOW TO USE SentiStrength-SE
# 1. Download the tool from https://laser.cs.uno.edu/Projects/Projects.html
# 2. unpack zip, open Terminal and navigate to Folder, e.g.,
# $ cd SentiStrength-SE_v1.5/
# 3. Start SentiStrength-SE:
# $ java -jar SentiStrength-SE_V1.5.jar
# this will open the SentiStrength-SE GUI
#
# 4. transform the dataset into the input format and generate
#    the empty result files using get_sentistrengthse_input_files()

# 5. In SentiStrength-SE:
#  a) Input --> select the input file (e.g., study_x_maximal_preprocessing_sentistrength_input.txt)
#  b) Input ---> set column number to Annotate to 2
#  c) Input ---> set column number to annotate and to save to to 2,1
#    (this will save the output in the format Message_id   score

#  d) Now click on "Detect Sentiments" and choose the corresponding
#     results file (e.g., study_x_maximal_preprocessing_sentistrength_result.csv)
#  ---> Steps a) and d) have to be repeated manually for each input/result file
#
# 6. Get Results into readable form
# use map_sentistrengthse_results() to read in the results and transform them into a usable form
# that can be easily read into a dataframe


def get_sentistrengthse_input_files(msg_file):
    df = pd.read_csv(msg_file)

    output_name = msg_file[:(msg_file.find(".csv"))] + "__sentistrength_input.txt"
    result_file_name = msg_file[:(msg_file.find(".csv"))] + "__sentistrength_result.csv"

    with open(output_name, 'a') as out:
        writer = csv.writer(out, delimiter="\t")

        for index, msg in df.iterrows():
            text = msg['Content']
            if isinstance(text, str) and text:
                new_text = text.replace("\r", "").replace("\n", " ").replace("\t", " ")

                row = [msg["Message_id"], new_text]
                writer.writerow(row)

    out.close()

    with open(result_file_name, 'w') as empty_result_file:
        pass
    empty_result_file.close()


def transform_all_datasets():
    study2_files = ["../batch_2019-10-18_4_maximal_processing.csv", "../batch_2019-10-18_3_advanced_processing.csv",
                    "../batch_2019-10-18_2_simple_processing.csv", "../batch_2019-10-18_1_minimal_processing.csv"]

    study1_files = ["../batch_2019-04-15_4_maximal_processing.csv", "../batch_2019-04-15_3_advanced_processing.csv",
                    "../batch_2019-04-15_2_simple_processing.csv", "../batch_2019-04-15_1_minimal_processing.csv"]

    for f2 in study2_files:
        get_sentistrengthse_input_files(f2)

    for f1 in study1_files:
        get_sentistrengthse_input_files(f1)


def map_sentistrengthse_results(results_file):
    lines = []
    with open(results_file, 'r') as fp:
        read_lines = fp.readlines()

        for line in read_lines:
            msg_id = line[:-7]
            pos_score = line[-5:-4]
            neg_score = line[-3:-1]

            lines.append([msg_id, pos_score, neg_score])

    df = pd.DataFrame.from_records(lines)

    output_name = results_file[:(results_file.find("result.csv"))] + "scores.csv"

    df.to_csv(output_name, header=False, index=False, sep=";")


# transform_all_datasets()

def map_all_results_to_scores():
    study2_files = ["../batch_2019-10-18_4_maximal_processing__sentistrength_result.csv",
                    "../batch_2019-10-18_3_advanced_processing__sentistrength_result.csv",
                    "../batch_2019-10-18_2_simple_processing__sentistrength_result.csv",
                    "../batch_2019-10-18_1_minimal_processing__sentistrength_result.csv"]

    study1_files = ["../batch_2019-04-15_4_maximal_processing__sentistrength_result.csv",
                    "../batch_2019-04-15_3_advanced_processing__sentistrength_result.csv",
                    "../batch_2019-04-15_2_simple_processing__sentistrength_result.csv",
                    "../batch_2019-04-15_1_minimal_processing__sentistrength_result.csv"]

    for f2 in study2_files:
        map_sentistrengthse_results(f2)

    for f1 in study1_files:
        map_sentistrengthse_results(f1)


#map_all_results_to_scores()

def sentistrength_binary_evaluation(scores_file, labels_file, mode=None):

    senti_label_neg = "senti_label_negative_mean"
    senti_label_pos = "senti_label_positive_mean"

    if mode == "aggressive_if_one_is_aggressive":
       senti_label_neg = "senti_label_negative_amin"
       senti_label_pos = "senti_label_positive_amax"
    elif mode == "all_but_one_agree":
       senti_label_neg = "senti_label_negative_median"
       senti_label_pos = "senti_label_positive_median"

    scores_df = pd.read_csv(scores_file, sep=";", header=None, names=['msg_id', 'pos_score', 'neg_score'])
    scores_df['pos_score'] = scores_df['pos_score'].astype(float)
    scores_df['neg_score'] = scores_df['neg_score'].astype(float)
    labels_df = pd.read_csv(labels_file, sep=";", usecols=["msg_id", senti_label_pos, senti_label_neg])
    print("\n = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    print("  Binary evaluation of   " + scores_file + ":")
    print("    Number of unclassifyable e-mails filtered out:   " + str(len(scores_df.loc[(scores_df['pos_score'] > 5) |
                                                                                          (scores_df['pos_score'] < 1) |
                                                                                          (scores_df['neg_score'] < -5) |
                                                                                          (scores_df['neg_score'] > -1) ])))
    print("    Number of e-mails without valid label:          " + str(len(scores_df) - len(labels_df)))

    # drop from scores:
    # - where score is out of range [1;5] for pos_score and out of range [-5;-1] for neg_score
    scores_df = scores_df.loc[(scores_df['pos_score'] <= 5) & (scores_df['pos_score'] >= 1)]
    scores_df = scores_df.loc[(scores_df['neg_score'] >= -5) & (scores_df['neg_score'] <= -1)]

    # nothing to drop from labels, invalid labels are already removed

    # Inner join where we only take those both have msg_id in common
    merged = pd.merge(scores_df, labels_df, on="msg_id", how="inner")
    print("    Number of remaining e-mails:                   " + str(len(merged)))

    non_aggressive = "non-aggressive (positive value)"  # for pos_score
    not_non_aggressive = "aggressive (positive value)"  # for pos_score
    aggressive = "aggressive (negative value)"  # for neg_score
    not_aggressive = "non-aggressive (negative value)"  # for neg_score

    # apply threshold
    # sentistrength-se returns two scores, a positive score [1; 5] and a negative score [-5; -1]
    # [-1; 1] represents a neutral score
    # our binary classification: if there is postive sentiment (>1), it is non-aggressive
    # if there is
    merged.loc[(merged['pos_score'] > 1) | ((merged['pos_score'] == 1) & (merged['neg_score'] == -1 )), 'binary_pos_score'] = non_aggressive
    merged.loc[(merged['pos_score'] <= 1) & (merged['neg_score'] < -1), 'binary_pos_score'] = not_non_aggressive
    merged.loc[(merged['neg_score'] < -1), 'binary_neg_score'] = aggressive
    merged.loc[(merged['neg_score'] >= -1), 'binary_neg_score'] = not_aggressive

    # dump binary score to file
    binary_outfile = scores_file[:-4] + "_binary.csv"
    merged[['msg_id','binary_neg_score','binary_pos_score']].to_csv(binary_outfile, sep=';', index=False)

    merged.loc[(merged[senti_label_pos] > 1) | ((merged[senti_label_pos] == 1) & (merged[senti_label_neg] == -1)), 'senti_label_positive_binary'] = non_aggressive
    merged.loc[(merged[senti_label_pos] <= 1) & (merged[senti_label_neg] < -1), 'senti_label_positive_binary'] = not_non_aggressive
    merged.loc[merged[senti_label_neg] < -1, 'senti_label_negative_binary'] = aggressive
    merged.loc[merged[senti_label_neg] >= -1, 'senti_label_negative_binary'] = not_aggressive

    print("\n+++Positive Score:+++")
    print(merged.groupby('binary_pos_score')['binary_pos_score'].count())
    print(merged.groupby('senti_label_positive_binary')['senti_label_positive_binary'].count())
    print(metrics.classification_report(merged['senti_label_positive_binary'].values.astype(str),
                                        merged['binary_pos_score'].values.astype(str)))
    print("  Matthews Correlations score: " + str(
        metrics.matthews_corrcoef(merged['senti_label_positive_binary'].values.astype(str), merged['binary_pos_score'].values.astype(str))))

    print("\n+++Negative Score:+++")
    print(merged.groupby('binary_neg_score')['binary_neg_score'].count())
    print(merged.groupby('senti_label_negative_binary')['senti_label_negative_binary'].count())

    print(metrics.classification_report(merged['senti_label_negative_binary'].values.astype(str),
                                        merged['binary_neg_score'].values.astype(str)))
    print("  Matthews Correlations score: " + str(
        metrics.matthews_corrcoef(merged['senti_label_negative_binary'].values.astype(str), merged['binary_neg_score'].values.astype(str))))

    print(" = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n")

    return merged


def evaluate_all_datasets(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study_all_labels = "../final_both_prestudies_labels" + m + "_excl_unsure.csv"
    study_all_files = ["../both_prestudies_4_maximal_processing__sentistrength_scores.csv",
                    "../both_prestudies_3_advanced_processing__sentistrength_scores.csv",
                    "../both_prestudies_2_simple_processing__sentistrength_scores.csv",
                    "../both_prestudies_1_minimal_processing__sentistrength_scores.csv"]

    for f in study_all_files:
        sentistrength_binary_evaluation(f, study_all_labels, mode)


def evaluate_all_datasets_separately(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study2_labels = "../final_batch_labels2" + m + "_excl_unsure.csv"
    study2_files = ["../batch_2019-10-18_4_maximal_processing__sentistrength_scores.csv",
                    "../batch_2019-10-18_3_advanced_processing__sentistrength_scores.csv",
                    "../batch_2019-10-18_2_simple_processing__sentistrength_scores.csv",
                    "../batch_2019-10-18_1_minimal_processing__sentistrength_scores.csv"]

    for f2 in study2_files:
        sentistrength_binary_evaluation(f2, study2_labels, mode)

    study1_labels = "../batch_2019-04-15__FINAL_labels" + m + "_excl_unsure.csv"
    study1_files = ["../batch_2019-04-15_4_maximal_processing__sentistrength_scores.csv",
                    "../batch_2019-04-15_3_advanced_processing__sentistrength_scores.csv",
                    "../batch_2019-04-15_2_simple_processing__sentistrength_scores.csv",
                    "../batch_2019-04-15_1_minimal_processing__sentistrength_scores.csv"]

    for f1 in study1_files:
        sentistrength_binary_evaluation(f1, study1_labels, mode)


