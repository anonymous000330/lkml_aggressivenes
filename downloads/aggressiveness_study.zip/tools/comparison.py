import pandas as pd
import csv

from sklearn import metrics

import numpy as np
from rpy2.robjects import DataFrame, FloatVector, IntVector
from rpy2.robjects.packages import importr
import rpy2.rinterface_lib.callbacks as rinterface
from math import isclose

import krippendorff
from utils.rater_agreement import get_icc_df


def binary_evaluation(scores_file, tools=['VADER','perspective','stanford','sentistrength'], mode=None):


    vader_df = pd.read_csv(scores_file[:-4] + "__VADER_scores_binary.csv", sep=";", header=0, names=['msg_id', 'binary_score'])
    vader_df['tool'] = "VADER"

    perspective_df = pd.read_csv(scores_file[:-4] + "__perspective_scores_binary.csv", sep=";", header=0, names=['msg_id', 'binary_score'])
    perspective_df['tool'] = "perspective"

    stanford_df = pd.read_csv(scores_file[:-4] + "__stanford_scores_binary.csv", sep=";", header=0, names=['msg_id', 'binary_score'])
    stanford_df['tool'] = "stanford"

    sentistrength_df = pd.read_csv(scores_file[:-4] + "__sentistrength_scores_binary.csv", sep=";", header=0, names=['msg_id', 'binary_neg_score', 'binary_pos_score'])
    sentistrength_df = sentistrength_df.drop(columns=['binary_pos_score']) #'binary_neg_score'
    sentistrength_df = sentistrength_df.rename(columns={"binary_neg_score": "binary_score"}) #'binary_pos_score'
    sentistrength_df['tool'] = "sentistrength"

    tools_df_list = []
    if 'VADER' in tools:
        tools_df_list.append(vader_df)
    if 'perspective' in tools:
        tools_df_list.append(perspective_df)
    if 'stanford' in tools:
        tools_df_list.append(stanford_df)
    if 'sentistrength' in tools:
        tools_df_list.append(sentistrength_df)

    tools_df = pd.concat(tools_df_list)
    msgs = tools_df['email_id'].unique()

    tools_df.loc[tools_df['binary_score'] == "aggressive", 'binary_score'] = 1
    tools_df.loc[tools_df['binary_score'] == "non-aggressive", 'binary_score'] = 0

    # fix sentistrength score names
    tools_df.loc[tools_df['binary_score'] == "aggressive (negative value)", 'binary_score'] = 1
    tools_df.loc[tools_df['binary_score'] == "non-aggressive (negative value)", 'binary_score'] = 0
    tools_df.loc[tools_df['binary_score'] == "non-aggressive (positive value)", 'binary_score'] = 0
    tools_df.loc[tools_df['binary_score'] == "aggressive (positive value)", 'binary_score'] = 1

    # as not tool user has classified every e-mail, add rows with NAN for a (tool,e-mail) pair if a tool has not
    # classified the respective e-mail
    for tool in tools:
       for msg in msgs:
           if tools_df[(tools_df.email_id == msg) & (tools_df.tool == tool)].empty:
               tools_df = pd.concat([tools_df, pd.DataFrame.from_records([{"email_id":msg, "tool":tool}], index="email_id")])

    # sort dataframe so that e-mails are in same order for all tools
    tools_df = tools_df.sort_values(["email_id", "tool"])

    tool_groups = tools_df[["email_id", "tool", "binary_score"]].groupby('tool')
    scores_per_tool = []

    for name, group in tool_groups:

        if name not in tools:
            continue

        if len(group) < len(msgs):
            raise Exception("There is something wrong with the number of labeled e-mails")

        scores_per_tool.append(group.binary_score.tolist())

    scores_per_tool_dict = {"binary_score": scores_per_tool}

    # get krippendorffs alphas (level of measurement does not make a difference for binary scores, though)
    # 1. nominal
    overall_nominal = round(krippendorff.alpha(scores_per_tool_dict["binary_score"], level_of_measurement="nominal"), 6)
    # 2. ordinal
    overall_ordinal = round(krippendorff.alpha(scores_per_tool_dict["binary_score"], level_of_measurement="ordinal"), 6)
    # 3. interval
    overall_interval = round(krippendorff.alpha(scores_per_tool_dict["binary_score"], level_of_measurement="interval"), 6)
    # 4. ratio
    overall_ratio = round(krippendorff.alpha(scores_per_tool_dict["binary_score"], level_of_measurement="ratio"), 6)

    table_data = {
                    'nominal': [overall_nominal],
                    "ordinal": [overall_ordinal],
                    "interval": [overall_interval],
                    "ratio": [overall_ratio]
                    }

    print("\nInter-Tool Agreement: binary scores")
    print(pd.DataFrame.from_dict(table_data, orient='index', columns=['overall label']))

    df_overall = get_icc_df(scores_per_tool_dict["binary_score"])

    # suppress spurious and verbose R warnings that cannot be fixed via rpy2
    storage = []
    def write_to_storage(x):
        storage.append(x)
    rinterface.consolewrite_warnerror = write_to_storage

    r_icc = importr("ICC")
    icc_res_overall = r_icc.ICCbare("groups", "values", data=df_overall)

    print(pd.DataFrame({'ICC binary scores': [icc_res_overall[0]]}))


def calculate_binary_tool_agreement(tools=['VADER','perspective','stanford','sentistrength'], mode=None):

    study_all_files = ["../both_prestudies_4_maximal_processing.csv",
                    "../both_prestudies_3_advanced_processing.csv",
                    "../both_prestudies_2_simple_processing.csv",
                    "../both_prestudies_1_minimal_processing.csv"]

    for f in study_all_files:
        binary_evaluation(f, tools, mode)


def calculate_binary_tool_agreement_separately(tools=['VADER','perspective','stanford','sentistrength'], mode=None):


    study2_files = ["../batch_2019-10-18_4_maximal_processing.csv",
                    "../batch_2019-10-18_3_advanced_processing.csv",
                    "../batch_2019-10-18_2_simple_processing.csv",
                    "../batch_2019-10-18_1_minimal_processing.csv"]

    for f2 in study2_files:
        binary_evaluation(f2, tools, mode)

    study1_files = ["../batch_2019-04-15_4_maximal_processing.csv",
                    "../batch_2019-04-15_3_advanced_processing.csv",
                    "../batch_2019-04-15_2_simple_processing.csv",
                    "../batch_2019-04-15_1_minimal_processing.csv"]

    for f1 in study1_files:
        binary_evaluation(f1, tools, mode)

