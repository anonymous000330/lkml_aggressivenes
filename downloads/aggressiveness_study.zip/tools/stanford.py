from pycorenlp import StanfordCoreNLP
import csv
import pandas as pd
from timeit import default_timer as timer
from datetime import timedelta, datetime

from sklearn import metrics

nlp = StanfordCoreNLP('http://localhost:9000')
# NOTE:
# stanfordCoreNLP must be installed and the StanfordCoreNLPServer running:
# pip install pycorenlp
# in the terminal, change to the stanford-corenlp directory and start the server, e.g.,
# $ cd stanford-corenlp-full-2018-10-05/
# $ java -mx4g -cp "*" edu.stanford.nlp.pipeline.StanfordCoreNLPServer


def get_stanford_score(index, msg_id, text):
    score = "None"
    if isinstance(text, str) and text:
        new_text = text.replace('\t', ' ').replace('\n\n', '\n').replace('\r\n', '\n')
        result = (nlp.annotate(new_text,
                               properties={
                                   'annotators': 'sentiment',
                                   'outputFormat': 'json',
                                   'timeout': 60000,
                               })
                  )
        try:
            score = result['sentences'][0]['sentiment']
        except:
            print("\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--")
            print("Oooops! Error accessing the result (StanfordCoreNLP)")
            print("Index: " + str(index) + "  MSG_ID:  " + msg_id)
            print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--\n")

    return score


def map_stanford_score(score, mode='multi'):
    """

    :param score:
    :param mode: multi or binary
    :return:
    """
    score_map = {
        "Verypositive": "Non-aggressive",
        "Positive": "Non-aggressive",
        "Neutral": "Non-aggressive",
        "Negative": "Aggressive",
        "Verynegative": "Aggressive",
    }

    if 'multi' in mode:
        score_map = {
            "Verypositive": "Friendly",
            "Positive": "Friendly",
            "Neutral": "Neutral",
            "Negative": "Mildly aggressive",
            "Verynegative": "Strongly aggressive",
        }
    else:
        pass

    return score_map.get(score, "None")


def get_scores(msg_file):
    msg_df = pd.read_csv(msg_file, encoding='utf8')
    output_name = msg_file[:(msg_file.find(".csv"))] + "__stanford_scores.csv"
    now = datetime.now().strftime('%d.%m.%Y, %H:%M')
    print("* * * * * * * * * " + now + ":  Starting to analyze    " + msg_file + "    ! ! ! ! ! !")
    start = timer()

    with open(output_name, 'a') as out:
        writer = csv.writer(out, delimiter=";")

        for index, msg in msg_df.iterrows():
            score = get_stanford_score(index, msg["Message_id"], msg["Content"])
            row = [msg["Message_id"], score]
            writer.writerow(row)

    out.close()
    end = timer()
    now = datetime.now().strftime('%d.%m.%Y, %H:%M')
    print("* elapsed time:  " + str(timedelta(seconds=end - start)))
    print("* * * * * * * * * " + now + ":  Finished scoring file    " + msg_file + "    ! ! ! ! ! !")


def score_all_datasets():
    study2_files = ["../batch_2019-10-18_4_maximal_processing.csv", "../batch_2019-10-18_3_advanced_processing.csv",
                    "../batch_2019-10-18_2_simple_processing.csv", "../batch_2019-10-18_1_minimal_processing.csv"]

    study1_files = ["../batch_2019-04-15_4_maximal_processing.csv", "../batch_2019-04-15_3_advanced_processing.csv",
                    "../batch_2019-04-15_2_simple_processing.csv", "../batch_2019-04-15_1_minimal_processing.csv"]

    for f2 in study2_files:
        get_scores(f2)

    for f1 in study1_files:
        get_scores(f1)


def stanford_binary_evaluation(scores_file, labels_file, mode=None):

    overall_label = "overall_label_mean"

    if mode == "aggressive_if_one_is_aggressive":
        overall_label = "overall_label_amax"
    elif mode == "all_but_one_agree":
        overall_label = "overall_label_do_all_but_one_agree"

    scores_df = pd.read_csv(scores_file, sep=";", header=None, names=['msg_id', 'stanford_score'])
    labels_df = pd.read_csv(labels_file, sep=";", usecols=["msg_id", overall_label])
    print("\n = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    print("  Binary evaluation of   " + scores_file + ":")
    print("    Number of unclassifyable e-mails filtered out:   " + str(len(scores_df.loc[scores_df['stanford_score'] == "None"])))
    print("    Number of e-mails without valid label:          " + str(len(scores_df) - len(labels_df)))

    # drop from scores:
    # - where score is -3 and where score is -2
    scores_df = scores_df.loc[scores_df['stanford_score'] != "None"]

    # nothing to drop from labels, invalid labels are already removed

    # Inner join where we only take those both have msg_id in common
    merged = pd.merge(scores_df, labels_df, on="msg_id", how="inner")
    print("    Number of remaining e-mails:                   " + str(len(merged)))

    non_aggressive = "non-aggressive"
    aggressive = "aggressive"

    # apply threshold
    merged['stanford_score'] = merged['stanford_score'].apply(lambda x: map_stanford_score(x, mode="binary"))
    merged.loc[merged['stanford_score'] == "Non-aggressive", 'binary_score'] = non_aggressive
    merged.loc[merged['stanford_score'] == "Aggressive", 'binary_score'] = aggressive

    # dump binary score to file
    binary_outfile = scores_file[:-4] + "_binary.csv"
    merged[['msg_id','binary_score']].to_csv(binary_outfile, sep=';', index=False)

    merged.loc[merged[overall_label] <= 0.5, 'binary_label'] = non_aggressive
    merged.loc[merged[overall_label] > 0.5, 'binary_label'] = aggressive

    print(merged.groupby('binary_score')['binary_score'].count())
    print(merged.groupby('binary_label')['binary_label'].count())
    print(metrics.classification_report(merged['binary_label'].values.astype(str),
                                        merged['binary_score'].values.astype(str)))
    print("  Matthews Correlations score: " + str(
        metrics.matthews_corrcoef(merged['binary_label'].values.astype(str), merged['binary_score'].values.astype(str))))

    print(" = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n")

    return merged


def evaluate_all_datasets(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study_all_labels = "../final_both_prestudies_labels" + m + "_excl_unsure.csv"
    study_all_files = ["../both_prestudies_4_maximal_processing__stanford_scores.csv",
                    "../both_prestudies_3_advanced_processing__stanford_scores.csv",
                    "../both_prestudies_2_simple_processing__stanford_scores.csv",
                    "../both_prestudies_1_minimal_processing__stanford_scores.csv"]

    for f in study_all_files:
        stanford_binary_evaluation(f, study_all_labels, mode)


def evaluate_all_datasets_separately(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study2_labels = "../final_batch_labels2" + m + "_excl_unsure.csv"
    study2_files = ["../batch_2019-10-18_4_maximal_processing__stanford_scores.csv",
                    "../batch_2019-10-18_3_advanced_processing__stanford_scores.csv",
                    "../batch_2019-10-18_2_simple_processing__stanford_scores.csv",
                    "../batch_2019-10-18_1_minimal_processing__stanford_scores.csv"]

    for f2 in study2_files:
        stanford_binary_evaluation(f2, study2_labels, mode)

    study1_labels = "../batch_2019-04-15__FINAL_labels" + m + "_excl_unsure.csv"
    study1_files = ["../batch_2019-04-15_4_maximal_processing__stanford_scores.csv",
                    "../batch_2019-04-15_3_advanced_processing__stanford_scores.csv",
                    "../batch_2019-04-15_2_simple_processing__stanford_scores.csv",
                    "../batch_2019-04-15_1_minimal_processing__stanford_scores.csv"]

    for f1 in study1_files:
        stanford_binary_evaluation(f1, study1_labels, mode)
