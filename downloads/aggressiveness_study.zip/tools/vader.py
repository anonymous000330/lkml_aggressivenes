from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
import csv

from timeit import default_timer as timer
from datetime import timedelta, datetime

from sklearn import metrics

#import nltk

# nltk.download('vader_lexicon')

def get_vader_score(index, msg_id, text):
    sid = SentimentIntensityAnalyzer()
    compound = ""
    pos = ""
    neg = ""
    neu = ""

    if isinstance(text, str) and text:
        ss = sid.polarity_scores(text)
        compound = ss['compound']
        pos = ss['pos']
        neg = ss['neg']
        neu = ss['neu']
    else:
        print("\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--")
        print("Oooops! An ERROR occured in VADER)")
        print("Index: " + str(index) + "  MSG_ID:  " + msg_id)
        print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--\n")

    return [compound, pos, neg, neu]


def get_scores(msg_file):
    msg_df = pd.read_csv(msg_file, encoding='utf8')
    output_name = msg_file[:(msg_file.find(".csv"))] + "__VADER_scores.csv"
    now = datetime.now().strftime('%d.%m.%Y, %H:%M')
    print("* * * * * * * * * " + now + ":  Starting to analyze    " + msg_file + "    ! ! ! ! ! !")
    start = timer()

    with open(output_name, 'a') as out:
        writer = csv.writer(out, delimiter=";")

        for index, msg in msg_df.iterrows():
            score = get_vader_score(index, msg["Message_id"], msg["Content"])
            # score in VADER is a 4-tuple: 'compound': [-1,1], 'pos': [0,1], 'neg': [0,1], 'neu': [0,1]

            if score is None:  # when exception occured
                # TODO: improve error handling, possibly use continue instead of break and write all message_ids
                #       into separate file where error occured?
                print("   Name of file:  " + msg_file)
                print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--\n\n")
                score = [-2, -2, -2, -2]  # perhaps use nan/empty string instead?

            if score["pos"] == score["neg"] == score["neu"] == 0.0 & score["compound"] == 1.0:
                print("   Name of file:  " + msg_file)
                print("+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+--\n\n")
                score = [-3, -3, -3, -3]  # perhaps use nan/empty string instead?


            row = [msg["Message_id"]]
            row.extend(score)
            writer.writerow(row)

    out.close()
    end = timer()
    now = datetime.now().strftime('%d.%m.%Y, %H:%M')
    print("* elapsed time:  " + str(timedelta(seconds=end - start)))
    print("* * * * * * * * * " + now + ":  Finished scoring file    " + msg_file + "    ! ! ! ! ! !")


def score_all_datasets():
    study2_files = ["../batch_2019-10-18_4_maximal_processing.csv", "../batch_2019-10-18_3_advanced_processing.csv",
                    "../batch_2019-10-18_2_simple_processing.csv", "../batch_2019-10-18_1_minimal_processing.csv"]

    study1_files = ["../batch_2019-04-15_4_maximal_processing.csv", "../batch_2019-04-15_3_advanced_processing.csv",
                    "../batch_2019-04-15_2_simple_processing.csv", "../batch_2019-04-15_1_minimal_processing.csv"]

    for f2 in study2_files:
        get_scores(f2)

    for f1 in study1_files:
        get_scores(f1)

def vader_binary_evaluation(scores_file, labels_file, mode=None):

    overall_label = "overall_label_mean"

    if mode == "aggressive_if_one_is_aggressive":
        overall_label = "overall_label_amax"
    elif mode == "all_but_one_agree":
        overall_label = "overall_label_do_all_but_one_agree"

    scores_df = pd.read_csv(scores_file, sep=";", header=None, names=['msg_id', 'compound', 'pos', 'neg', 'neu'])
    labels_df = pd.read_csv(labels_file, sep=";", usecols=["msg_id", overall_label])
    print("\n = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    print("  Binary evaluation of   " + scores_file + ":")
    print("    Number of unclassifyable e-mails filtered out:   " + str(len(scores_df.loc[scores_df['compound'] == -2])))
    print("    Number of false classified e-mails filtered out: " + str(len(scores_df.loc[scores_df['compound'] == -3])))
    print("    Number of e-mails without valid label:          " + str(len(scores_df) - len(labels_df)))

    # drop from scores:
    # - where score is -3 and where score is -2
    scores_df = scores_df.loc[scores_df['compound'] >= -1]

    # nothing to drop from labels, invalid labels are already removed

    # Inner join where we only take those both have msg_id in common
    merged = pd.merge(scores_df, labels_df, on="msg_id", how="inner")
    print("    Number of remaining e-mails:                   " + str(len(merged)))

    non_aggressive = "non-aggressive"
    aggressive = "aggressive"

    # apply threshold
    merged.loc[merged['compound'] > -0.05, 'binary_score'] = non_aggressive
    merged.loc[merged['compound'] <= -0.05, 'binary_score'] = aggressive

    # dump binary score to file
    binary_outfile = scores_file[:-4] + "_binary.csv"
    merged[['msg_id','binary_score']].to_csv(binary_outfile, sep=';', index=False)

    merged.loc[merged[overall_label] <= 0.5, 'binary_label'] = non_aggressive
    merged.loc[merged[overall_label] > 0.5, 'binary_label'] = aggressive

    print(merged.groupby('binary_score')['binary_score'].count())
    print(merged.groupby('binary_label')['binary_label'].count())

    print(metrics.classification_report(merged['binary_label'].values.astype(str),
                                        merged['binary_score'].values.astype(str)))
    print("  Matthews Correlations score: " + str(
        metrics.matthews_corrcoef(merged['binary_label'].values.astype(str), merged['binary_score'].values.astype(str))))

    print(" = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n")

    return merged


def evaluate_all_datasets(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study_all_labels = "../final_both_prestudies_labels" + m + "_excl_unsure.csv"
    study_all_files = ["../both_prestudies_4_maximal_processing__VADER_scores.csv",
                    "../both_prestudies_3_advanced_processing__VADER_scores.csv",
                    "../both_prestudies_2_simple_processing__VADER_scores.csv",
                    "../both_prestudies_1_minimal_processing__VADER_scores.csv"]

    for f in study_all_files:
        vader_binary_evaluation(f, study_all_labels, mode)


def evaluate_all_datasets_separately(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study2_labels = "../final_batch_labels2" + m + "_excl_unsure.csv"
    study2_files = ["../batch_2019-10-18_4_maximal_processing__VADER_scores.csv",
                    "../batch_2019-10-18_3_advanced_processing__VADER_scores.csv",
                    "../batch_2019-10-18_2_simple_processing__VADER_scores.csv",
                    "../batch_2019-10-18_1_minimal_processing__VADER_scores.csv"]

    for f2 in study2_files:
        vader_binary_evaluation(f2, study2_labels, mode)

    study1_labels = "../batch_2019-04-15__FINAL_labels" + m + "_excl_unsure.csv"
    study1_files = ["../batch_2019-04-15_4_maximal_processing__VADER_scores.csv",
                    "../batch_2019-04-15_3_advanced_processing__VADER_scores.csv",
                    "../batch_2019-04-15_2_simple_processing__VADER_scores.csv",
                    "../batch_2019-04-15_1_minimal_processing__VADER_scores.csv"]

    for f1 in study1_files:
        vader_binary_evaluation(f1, study1_labels, mode)

