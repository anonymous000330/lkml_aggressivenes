import json
import requests
import csv
from time import sleep
import pandas as pd
import sklearn
from sklearn import metrics


# Shilpas API key ?
api_url = 'https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze?key=AIzaSyCboFtioTOGraWXp_ymTXV7RT8Bkgejmb8'


def get_perspective_score(index, msg_id, text):
    """

    :param index:
    :param msg_id:
    :param text:
    :return:
    """

    if not isinstance(text, str):  # deal with empty text (encoded as nan)
        return -1

    data_dict = {
        "comment": {
            "text": text
        },
        "languages": ["en"],
        "requestedAttributes": {
            "TOXICITY": {}
        }
    }
    data_json = json.dumps(data_dict)
    response = requests.post(url=api_url, data=data_json)
    response_dict = json.loads(response.content.decode('utf-8'))
    try:
        return response_dict['attributeScores']['TOXICITY']['summaryScore']['value']
    except:
        print("\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--")
        print("Oooops! Error accessing the response dictionary (perspective api)")
        print("Index: " + str(index) + "  MSG_ID:  " + msg_id)
        print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--\n")
        return None


def get_scores(msg_file, last_valid_index=0):
    """
    computes scores for the given msg_file and writes them into a csv where the first column is the Message_id and
    the second column is the score. Note:

    valid score range: 0.0 - 1.0;
    invalid score:
    -1 -> indicates that text input was empty;
    -2 -> indicates a failed classification attempt (e.g., text input was too long)

    :param msg_file:
    :param last_valid_index:
    :return:
    """
    msg_df = pd.read_csv(msg_file, encoding='utf8')

    output_name = msg_file[:(msg_file.find(".csv"))] + "__perspective_scores.csv"

    with open(output_name, 'a') as out:
        writer = csv.writer(out, delimiter=";")

        for index, msg in msg_df[last_valid_index:].iterrows():
            score = get_perspective_score(index, msg["Message_id"], msg["Content"])

            if score is None:  # when exception occured
                # TODO: improve error handling, possibly use continue instead of break and write all message_ids
                #       into separate file where error occured?
                print("   Name of file:  " + msg_file)
                print("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--\n\n")
                score = -2  # perhaps use nan/empty string instead?

            row = [msg["Message_id"], score]
            writer.writerow(row)

            sleep(5)
    out.close()
    print("* * * * * * * * * Finished scoring file    " + msg_file + "    ! ! ! ! ! !")


def score_all_datasets():
    study2_files = ["../batch_2019-10-18_4_maximal_processing.csv",
                    "../batch_2019-10-18_3_advanced_processing.csv",
                    "../batch_2019-10-18_2_simple_processing.csv", "../batch_2019-10-18_1_minimal_processing.csv"]

    study1_files = ["../batch_2019-04-15_4_maximal_processing.csv",
                    "../batch_2019-04-15_3_advanced_processing.csv",
                    "../batch_2019-04-15_2_simple_processing.csv", "../batch_2019-04-15_1_minimal_processing.csv"]

    for f2 in study2_files:
        get_scores(f2)

    for f1 in study1_files:
        get_scores(f1)


def perspective_binary_evaluation(scores_file, labels_file, mode=None):

    overall_label = "overall_label_mean"

    if mode == "aggressive_if_one_is_aggressive":
        overall_label = "overall_label_amax"
    elif mode == "all_but_one_agree":
        overall_label = "overall_label_do_all_but_one_agree"

    scores_df = pd.read_csv(scores_file, sep=";", header=None, names=['msg_id', 'score'])
    labels_df = pd.read_csv(labels_file, sep=";", usecols=["msg_id", overall_label])
    print("\n = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =")
    print("  Binary evaluation of   " + scores_file + ":")
    print("    Number of empty e-mails filtered out:            " + str(len(scores_df.loc[scores_df['score'] == -1])))
    print("    Number of unclassifyable e-mails filtered out:   " + str(len(scores_df.loc[scores_df['score'] == -2])))
    print("    Number of e-mails without valid label:          " + str(len(scores_df) - len(labels_df)))

    # drop from scores:
    # - where score is -1 and where score is -2
    scores_df = scores_df.loc[scores_df['score'] >= 0]

    # nothing to drop from labels, invalid labels are already removed

    # Inner join where we only take those both have msg_id in common
    merged = pd.merge(scores_df, labels_df, on="msg_id", how="inner")
    print("    Number of remaining e-mails:                   " + str(len(merged)))

    non_aggressive = "non-aggressive"
    aggressive ="aggressive"

    # apply threshold
    merged.loc[merged['score'] <= 0.5, 'binary_score'] = non_aggressive
    merged.loc[merged['score'] > 0.5, 'binary_score'] = aggressive

    # dump binary score to file
    binary_outfile = scores_file[:-4] + "_binary.csv"
    merged[['msg_id','binary_score']].to_csv(binary_outfile, sep=';', index=False)

    merged.loc[merged[overall_label] <= 0.5, 'binary_label'] = non_aggressive
    merged.loc[merged[overall_label] > 0.5, 'binary_label'] = aggressive

    print(merged.groupby('binary_score')['binary_score'].count())
    print(merged.groupby('binary_label')['binary_label'].count())

    print(metrics.classification_report(merged['binary_label'].values.astype(str),
                                        merged['binary_score'].values.astype(str)))
    print("  Matthews Correlations score: " + str(
        metrics.matthews_corrcoef(merged['binary_label'].values.astype(str), merged['binary_score'].values.astype(str))))

    print(" = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n")

    return merged


def evaluate_all_datasets(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study_all_labels = "../final_both_prestudies_labels" + m + "_excl_unsure.csv"
    study_all_files = ["../both_prestudies_4_maximal_processing__perspective_scores.csv",
                    "../both_prestudies_3_advanced_processing__perspective_scores.csv",
                    "../both_prestudies_2_simple_processing__perspective_scores.csv",
                    "../both_prestudies_1_minimal_processing__perspective_scores.csv"]

    for f in study_all_files:
        perspective_binary_evaluation(f, study_all_labels, mode)


def evaluate_all_datasets_separately(mode=None):

    MODE_ALL_BUT_ONE_AGREE = "all_but_one_agree"
    MODE_ONE_AGGRESSIVE = "aggressive_if_one_is_aggressive"
    one_aggressive = ("_atLeastOneAggr" if mode == MODE_ONE_AGGRESSIVE else "")
    all_but_one_agree = ("_allButOneAgree" if mode == MODE_ALL_BUT_ONE_AGREE else "")
    m = one_aggressive + all_but_one_agree

    study2_labels = "../final_batch_labels2" + m + "_excl_unsure.csv"
    study2_files = ["../batch_2019-10-18_4_maximal_processing__perspective_scores.csv",
                    "../batch_2019-10-18_3_advanced_processing__perspective_scores.csv",
                    "../batch_2019-10-18_2_simple_processing__perspective_scores.csv",
                    "../batch_2019-10-18_1_minimal_processing__perspective_scores.csv"]

    for f2 in study2_files:
        perspective_binary_evaluation(f2, study2_labels, mode)

    study1_labels = "../final_batch_labels" + m + "_excl_unsure.csv"
    study1_files = ["../batch_2019-04-15_4_maximal_processing__perspective_scores.csv",
                    "../batch_2019-04-15_3_advanced_processing__perspective_scores.csv",
                    "../batch_2019-04-15_2_simple_processing__perspective_scores.csv",
                    "../batch_2019-04-15_1_minimal_processing__perspective_scores.csv"]

    for f1 in study1_files:
        perspective_binary_evaluation(f1, study1_labels, mode)

