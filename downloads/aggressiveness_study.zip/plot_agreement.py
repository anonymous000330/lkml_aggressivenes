import secrets
import pandas as pd
import krippendorff
import numpy as np
from matplotlib import pyplot as plt
from scipy.stats import linregress



first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")

data_complete = pd.concat([first_batch_data, second_batch_data])
data_complete = data_complete[data_complete["corrupted"] == 0]
data_complete = data_complete[data_complete["spam"] == 0]
data_complete = data_complete[data_complete["auto_generated"] == 0]

unsure_mail_ids = pd.read_csv(f"unsure_emails.csv", sep=",").rename(columns={"Message_id" : "msg_id"})

common = data_complete.merge(unsure_mail_ids, on=["msg_id"])
data_unsure = data_complete[data_complete["msg_id"].isin(common["msg_id"])]
data_difference = data_complete[~data_complete["msg_id"].isin(common["msg_id"])]

def build_mails_df(mail_data, all_targets = True):
    mails = {}
    targets = {}
    for msg_id in mail_data["msg_id"].unique():
        mail = mail_data.loc[mail_data['msg_id'] == msg_id]

        targets[msg_id] = get_all_targets_simplified(mail) if all_targets else get_most_prominent_target_simplified(mail)

        mail["human"] = mail["target_recipient"] + mail["target_thirdparty"] + mail["target_self"]
        mail["other"] = mail["target_quoted"] + mail["target_other"]
        mail["technical"] = mail["target_technical"]
        mail["none"] = mail["target_none"]

        if all_targets:
            mail = mail[["target_recipient", "target_thirdparty", "target_technical", "target_self", "target_quoted", "target_other", "target_none"]]
        else:
            mail = mail[["human", "technical", "other", "none"]]

        mails[msg_id] = mail.values.tolist()
    return mails, targets

def get_krippendorff_alpha(mails):
    result = {}
    for msg_id in mails:
        data = mails[msg_id]
        result[msg_id] = krippendorff.alpha(data, level_of_measurement="ordinal")
    return result

TARGET_SIMPLIFICATION = {
    "target_recipient" : "human",
    "target_thirdparty" : "human",
    "target_self" : "human",
    "target_technical" : "technical",
    "target_quoted" : "other", 
    "target_other" : "other", 
    "target_none" : "none"
}

TARGET_SIMPLIFICATION_REVERSE = {
    "human" : ["target_recipient", "target_thirdparty", "target_self"],
    "technical" : ["target_technical"],
    "other" : ["target_other", "target_quoted"],
    "none" : ["target_none"]
}

def get_all_targets_simplified(mail):
    mail_agg = mail.groupby(by = "msg_id").agg({
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
    })
    result = []

    if mail_agg.iloc[0]["target_recipient"] + mail_agg.iloc[0]["target_thirdparty"] + mail_agg.iloc[0]["target_self"] > 0:
        result.append("human")
    if mail_agg.iloc[0]["target_quoted"] + mail_agg.iloc[0]["target_other"]> 0:
        result.append("other")
    if mail_agg.iloc[0]["target_technical"] > 0:
        result.append("technical")
    if mail_agg.iloc[0]["target_none"] > 0:
        result.append("none")

    return result

def get_most_prominent_target_simplified(mail):
    mail_agg = mail.groupby(by = "msg_id").agg({
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
    })
    mail_agg["human"] = mail_agg["target_recipient"] + mail_agg["target_thirdparty"] + mail_agg["target_self"]
    mail_agg["other"] = mail_agg["target_quoted"] + mail_agg["target_other"]
    mail_agg["technical"] = mail_agg["target_technical"]
    mail_agg["none"] = mail_agg["target_none"]
   
    mail_agg = mail_agg[["human", "technical", "other", "none"]]

    prominent_target = mail_agg.idxmax(axis = 1).iloc[0]
    return [prominent_target]

def get_alphas_by_targets(targets, alphas):
    x = []
    y = []

    human = []
    technical = []
    other = []
    none = []
    
    for msg_id in targets:
        if np.isnan(alphas[msg_id]):
            continue 

        if "human" in targets[msg_id]:
            x.append("human")
            y.append(alphas[msg_id])
            human.append(alphas[msg_id])
        if "technical" in targets[msg_id]:
            x.append("technical")
            y.append(alphas[msg_id])
            technical.append(alphas[msg_id])
        if "other" in targets[msg_id]:
            x.append("other")
            y.append(alphas[msg_id])
            other.append(alphas[msg_id])
        if "none" in targets[msg_id]:
            x.append("none")
            y.append(alphas[msg_id])
            none.append(alphas[msg_id])

    human_avg = np.median(np.array(human))
    technical_avg = np.median(np.array(technical))
    other_avg = np.median(np.array(other))
    none_avg = np.median(np.array(none))

    return x, y, human_avg, technical_avg, other_avg, none_avg

def plot_inter_rater_agreement(all_targets = True):
    # get all mails that are not labelled unsure
    mails, targets = build_mails_df(data_difference, all_targets = all_targets)
    alphas = get_krippendorff_alpha(mails)
    x, y, human_avg, technical_avg, other_avg, none_avg = get_alphas_by_targets(targets, alphas)
  
    # then get all unsure mails
    mails, targets = build_mails_df(data_unsure, all_targets = all_targets)
    alphas = get_krippendorff_alpha(mails)
    x_unsure, y_unsure, human_avg_unsure, technical_avg_unsure, other_avg_unsure, none_avg_unsure = get_alphas_by_targets(targets, alphas)

    # i = list(mails.keys())[54]
    # m = mails[list(mails.keys())[54]]
    # r = krippendorff.alpha(m, level_of_measurement="ordinal")

    plt.figure(figsize = (10, 10))

    if (all_targets):
        plt.title("Inter-rater agreement for each mail by all aggression targets")
        plt.xlabel("Aggression target")
    else:
        plt.title("Inter-rater agreement for each mail by most prominent aggression target")
        plt.xlabel("Most prominent agression target")    

    plt.ylabel("Inter-rater agreement (Krippendorff's Alpha)")

    plt.plot(
        ["human", "technical", "other", "none"], 
        [human_avg, technical_avg, other_avg, none_avg],
        label = "Median inter-rater agreement of none-'unsure' mails over all targets")

    plt.plot(
        ["human", "technical", "other", "none"], 
        [human_avg_unsure, technical_avg_unsure, other_avg_unsure, none_avg_unsure],
        label = "Median inter-rater agreement of 'unsure' mails over all targets")

    plt.scatter(x, y, s = 70, label = "Inter-rater agreement over all targets of mails not categorized 'unsure'")
    plt.scatter(x_unsure, y_unsure, s = 35, label = "Inter-rater agreement over all targets of mails categorized 'unsure'")
    plt.legend()

    # plt.show()
    plt.savefig("plots/IRA_most_prominent_target.svg")

    print("Median all but unsure")
    print(["human", "technical", "other", "none"])
    print([human_avg, technical_avg, other_avg, none_avg])
    print("Median unsure")
    print(["human", "technical", "other", "none"])
    print([human_avg_unsure, technical_avg_unsure, other_avg_unsure, none_avg_unsure])

def plot_target_distribution(simplified = True):    
    plt.style.use('tableau-colorblind10')

    data_unsure = pd.read_csv("unsure_mails_with_agg_data.csv", sep = ";") 
    data_complete = pd.read_csv("complete_mails_with_agg_data.csv", sep = ";") 

    data_complete["human"] = data_complete["target_recipient"] + data_complete["target_thirdparty"] + data_complete["target_self"]
    data_complete["other"] = data_complete["target_quoted"] + data_complete["target_other"]
    data_complete["technical"] = data_complete["target_technical"]
    data_complete["none"] = data_complete["target_none"]

    data_unsure["human"] = data_unsure["target_recipient"] + data_unsure["target_thirdparty"] + data_unsure["target_self"]
    data_unsure["other"] = data_unsure["target_quoted"] + data_unsure["target_other"]
    data_unsure["technical"] = data_unsure["target_technical"]
    data_unsure["none"] = data_unsure["target_none"]

    common = data_complete.merge(data_unsure, on=["msg_id"])
    data_difference = data_complete[~data_complete["msg_id"].isin(common["msg_id"])]

    # # Plot of all unsure mails
    fig, ax = plt.subplots(figsize=(15,10))
    x = [i + 1 for i in range(len(data_unsure))] #data_unsure["msg_id"]   
    ax.set_xlabel("Mails labelled 'unsure'")

    plt.title("Distribution of (simplified) aggression targets per mail")
    for target in TARGET_SIMPLIFICATION_REVERSE:
        targets_to_sum = TARGET_SIMPLIFICATION_REVERSE[target]
        y_unsure = data_unsure[targets_to_sum].sum(axis = 1)

        ax.bar(x, y_unsure, label = target) 

    ax.legend()    
    # plt.show()
    plt.savefig("plots/target_distr_unsure.svg")

    # Prepare data for the next two plots
    non_unsure_agg = data_difference.loc[data_difference["agressive_votes"] > data_difference ["not_agressive_votes"]]
    non_unsure_nonagg = data_difference.loc[data_difference["agressive_votes"] < data_difference ["not_agressive_votes"]]

    # Remove mails that have neither human nor technical ratings in order to improve readability
    non_unsure_nonagg = non_unsure_nonagg.loc[
        (non_unsure_nonagg["human"] > 0) | 
        (non_unsure_nonagg["technical"] > 0)]

    # non_unsure_nonagg.to_csv("test.csv", sep=";")

    # Plot all non-unsure mails with majority of aggressive ratings
    fig, ax = plt.subplots(figsize=(10,10))
    x = [i + 1 for i in range(len(non_unsure_agg))]
    ax.set_xlabel("Mails not labelled 'unsure' rated 'aggressive'")

    plt.title("Distribution of (simplified) aggression targets per mail")
    for target in TARGET_SIMPLIFICATION_REVERSE:
        y_unsure = non_unsure_agg[target]
        ax.bar(x, y_unsure, label = target)
   
    ax.legend()
    # plt.show()
    plt.savefig("plots/target_distr_non_unsure_aggressive.svg")

    # Plot all non-unsure mails with majority of non-aggressive ratings
    fig, ax = plt.subplots(figsize=(15, 10))
    x = [i + 1 for i in range(len(non_unsure_nonagg))]
    ax.set_xlabel("Mails not labelled 'unsure' rated 'not aggressive'")

    bottom = [0 for i in range(len(non_unsure_nonagg))]

    plt.title("Distribution of (simplified) aggression targets per mail\n(w/o mail only having 'none' and 'other' ratings)")
    
    for target in TARGET_SIMPLIFICATION_REVERSE:
        y_unsure = non_unsure_nonagg[target].tolist()
        ax.bar(x, y_unsure, label = target, bottom = bottom)
        bottom = np.add(bottom, y_unsure).tolist()

    ax.legend()
    # plt.show()
    plt.savefig("plots/target_distr_non_unsure_notaggressive_clean.svg")

def plot_none_distribution():
    data_unsure = pd.read_csv("unsure_mails_with_agg_data.csv", sep = ";")
    data_complete = pd.read_csv("complete_mails_with_agg_data.csv", sep = ";")     
    common = data_complete.merge(data_unsure, on=["msg_id"])
    data_difference = data_complete[~data_complete["msg_id"].isin(common["msg_id"])]

    only_none = data_complete[data_complete["target_none"] == data_complete["ratings"]]
    print(len(only_none))

    # Filter out mails rated only with target "none"
    data_unsure = data_unsure[data_unsure["target_none"] == data_unsure["ratings"]]
    data_difference = data_difference[data_difference["target_none"] == data_difference["ratings"]]

    non_unsure_agg = data_difference.loc[data_difference["agressive_votes"] > data_difference ["not_agressive_votes"]]
    non_unsure_nonagg = data_difference.loc[data_difference["agressive_votes"] < data_difference ["not_agressive_votes"]]
    unsure_agg = data_unsure.loc[data_unsure["agressive_votes"] > data_unsure ["not_agressive_votes"]]
    unsure_nonagg = data_unsure.loc[data_unsure["agressive_votes"] < data_unsure ["not_agressive_votes"]]

    fig, ax = plt.subplots()
    x = [i + 1 for i in range(len(non_unsure_agg))]
    
    plt.title("Distribution of mails with 'none' as the only aggression target")
    
    y = [len(non_unsure_agg), len(non_unsure_nonagg), len(unsure_agg), len(unsure_nonagg)]
    x = ["not unsure, aggressive", "not unsure, not aggressive", "unsure, aggressive", "unsure, not aggressive"]
    ax.bar(x, y)
    
    ax.legend()
    plt.show()


def get_unsure_mails(processing_level = "4_maximal"):
    # Get mails where despite high ratings for target recipient and technical most people labelled the mail "not aggressive"

    metadata_files = [
        "linux-kernel-sampled-header_2019-02-15",
        "linux-kernel-sampled-header_2019-02-08",
        "linux-kernel-sampled-header_batch_2019-04-15",
        "linux-kernel-sampled-header_batch2_2019-10-09",
        "linux-kernel-sampled-header_batch2_2019-10-12",
        "linux-kernel-sampled-header_batch2_2019-10-15",
        "linux-kernel-sampled-header_batch2_2019-10-18"
    ]

    all_metadata = pd.read_csv(f"tests/{metadata_files[0]}.csv").rename(columns={"Message_Id" : "msg_id"})
    
    for i in range(1, len(metadata_files)):
        m = pd.read_csv(f"tests/{metadata_files[i]}.csv").rename(columns={"Message_Id" : "msg_id"})

        m = m[~m["msg_id"].isin(all_metadata["msg_id"])]

        all_metadata = pd.concat([all_metadata, m])

    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails]).rename(columns={"Message_id" : "msg_id"})
   
    data_unsure = pd.read_csv("unsure_mails_with_agg_data.csv", sep = ";") 
    data_unsure = pd.merge(all_mails, data_unsure, on = "msg_id", how = "inner")
    data_unsure = pd.merge(all_metadata, data_unsure, on = "msg_id", how = "inner")    
    
    df = data_unsure[["msg_id", "From_name", "Content_x", "ratings", "agressive_votes", "not_agressive_votes", "target_recipient", "target_thirdparty", "target_self", "target_technical", "target_none", "target_other", "target_quoted"]]
    
    return df


def get_interesting_unsure_mails(processing_level = "4_maximal"):
    # Get mails where despite high ratings for target recipient and technical most people labelled the mail "not aggressive"

    metadata_files = [
        "linux-kernel-sampled-header_2019-02-15",
        "linux-kernel-sampled-header_2019-02-08",
        "linux-kernel-sampled-header_batch_2019-04-15",
        "linux-kernel-sampled-header_batch2_2019-10-09",
        "linux-kernel-sampled-header_batch2_2019-10-12",
        "linux-kernel-sampled-header_batch2_2019-10-15",
        "linux-kernel-sampled-header_batch2_2019-10-18"
    ]

    all_metadata = pd.read_csv(f"tests/{metadata_files[0]}.csv").rename(columns={"Message_Id" : "msg_id"})
    
    for i in range(1, len(metadata_files)):
        m = pd.read_csv(f"tests/{metadata_files[i]}.csv").rename(columns={"Message_Id" : "msg_id"})

        m = m[~m["msg_id"].isin(all_metadata["msg_id"])]

        all_metadata = pd.concat([all_metadata, m])

    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails]).rename(columns={"Message_id" : "msg_id"})
   
    data_unsure = pd.read_csv("unsure_mails_with_agg_data.csv", sep = ";") 
    data_unsure = pd.merge(all_mails, data_unsure, on = "msg_id", how = "inner")

    # We are interested in mails that have lots of ratings in aggression against humans but are not labelled as such
    data_unsure = data_unsure[data_unsure["target_technical"] + data_unsure["target_self"] + data_unsure["target_thirdparty"] + data_unsure["target_recipient"] >= data_unsure["agressive_votes"]]
    
    data_unsure = pd.merge(all_metadata, data_unsure, on = "msg_id", how = "inner")    
    
    df = data_unsure[["msg_id", "From_name", "Content_x", "ratings", "agressive_votes", "not_agressive_votes", "target_recipient", "target_thirdparty", "target_self", "target_technical", "target_none"]]
    df.to_csv("unsure_interesting_mail_ratings.csv", sep=";")

    return df

def get_all_mails(processing_level = "4_maximal"):
    metadata_files = [
        "linux-kernel-sampled-header_2019-02-15",
        "linux-kernel-sampled-header_2019-02-08",
        "linux-kernel-sampled-header_batch_2019-04-15",
        "linux-kernel-sampled-header_batch2_2019-10-09",
        "linux-kernel-sampled-header_batch2_2019-10-12",
        "linux-kernel-sampled-header_batch2_2019-10-15",
        "linux-kernel-sampled-header_batch2_2019-10-18"
    ]

    all_metadata = pd.read_csv(f"tests/{metadata_files[0]}.csv").rename(columns={"Message_Id" : "msg_id"})
    
    for i in range(1, len(metadata_files)):
        m = pd.read_csv(f"tests/{metadata_files[i]}.csv").rename(columns={"Message_Id" : "msg_id"})

        m = m[~m["msg_id"].isin(all_metadata["msg_id"])]

        all_metadata = pd.concat([all_metadata, m])

    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails]).rename(columns={"Message_id" : "msg_id"})
   
    data_complete = pd.read_csv("complete_mails_with_agg_data.csv", sep = ";") 
    data_complete = pd.merge(all_mails, data_complete, on = "msg_id", how = "inner")

    data_complete = pd.merge(all_metadata, data_complete, on = "msg_id", how = "inner")    
    
    df = data_complete[["msg_id", "From_name", "Content_x", "ratings", "agressive_votes", "not_agressive_votes", "target_recipient", "target_thirdparty", "target_self", "target_technical", "target_none"]]
    df.to_csv("unsure_interesting_mail_ratings.csv", sep=";")

    return df

def plot_author_distribution(interesting_mails):
    author_distr = interesting_mails.groupby(by = "From_name").size().reset_index(name="count")
    author_distr = author_distr.sort_values(by="count", ascending = False)

    fig, ax = plt.subplots(figsize=[30, 15])
    plt.title("Distribution of authors of ambiguous mails")    
    ax.set_xlabel("Authors")
    plt.xticks(rotation=45, ha="right")
    
    x = author_distr["From_name"]
    y = author_distr["count"]
    
    ax.bar(x, y, label = "Number of mails by author")

    ax.legend()
    # plt.show()
    plt.savefig("plots/all_mails_author_distr.svg")

def get_all_mail_data_with_agression_distinction(processing_level = "4_maximal",
                        excldue_unsure_ratings = False):
    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails]).rename(columns={"Message_id" : "msg_id"})

    # Now read and process the annotation data.
    first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
    second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")
   
    # Aggregate the important data over all annotations.
    all_data = pd.concat([first_batch_data, second_batch_data])
    
    all_data = all_data[all_data["corrupted"] == 0]
    all_data = all_data[all_data["spam"] == 0]
    all_data = all_data[all_data["auto_generated"] == 0]
    # If configured, exclude all ratings that are labelled as not sure.
    
    if excldue_unsure_ratings:
        all_data = all_data[all_data["not_sure"] == 0]

    # Add column according to the label (1 = agressive, 0 = not agressive).
    all_data["agressive_votes"] = all_data.apply(lambda x : 1 if x["label"] < 0 else 0, axis = 1)
    all_data["strongly_agressive_votes"] = all_data.apply(lambda x : 1 if x["label"] == -3 else 0, axis = 1)
    all_data["mildly_agressive_votes"] = all_data.apply(lambda x : 1 if x["label"] == -2 else 0, axis = 1)
    all_data["ratings"] = all_data.apply(lambda x : 0, axis = 1)

    all_data = all_data.groupby(by = "msg_id").agg({
        "ratings" : "count",
        "agressive_votes" : "sum",
        "strongly_agressive_votes" : "sum",
        "mildly_agressive_votes" : "sum",
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
        "meta" : "sum"
    })

    all_data["not_agressive_votes"] = all_data.apply(lambda x : x["ratings"] - x["agressive_votes"], axis = 1)
  
    all_data = pd.merge(all_mails, all_data, on = "msg_id", how = "inner")
    
    # return only valid rows.
    return all_data[all_data["agressive_votes"] + all_data["not_agressive_votes"] == all_data["ratings"]] 

def plot_interesting_unsure_mails_agression_distinction():
    data = get_all_mail_data_with_agression_distinction()
    interesting_mails = get_interesting_unsure_mails()
    interesting_mails = data[data["msg_id"].isin(interesting_mails["msg_id"])]
    
    fig, ax = plt.subplots(figsize=(15,10))
    x = [i + 1 for i in range(len(interesting_mails))]

    bottom = [0 for _ in range(len(interesting_mails))]

    plt.title("Ambiguous mails: Distribution of aggressiveness ratings")
    
    labels = {
        "not_agressive_votes" : "Not aggressive",
        "mildly_agressive_votes" : "Mildly aggressive",
        "strongly_agressive_votes" : "Strongly aggressive"
    }
    for t in ["not_agressive_votes", "mildly_agressive_votes", "strongly_agressive_votes"]:
        y = interesting_mails[t].tolist()
        ax.bar(x, y, label = labels[t], bottom = bottom)
        bottom = np.add(bottom, y).tolist()

    ax.legend()
    # plt.show()
    
    #paper version
    for item in ([ax.title, ax.xaxis.label, ax.yaxis.label] +
             ax.get_xticklabels() + ax.get_yticklabels() + ax.legend().get_texts()):
        item.set_fontsize(24)
    plt.savefig("plots/ambiguous_mails_aggr_distr.svg")

def print_strongly_ambiguous_mails():
    data = get_all_mail_data_with_agression_distinction()
    interesting_mails = get_interesting_unsure_mails()
    interesting_mails = data[data["msg_id"].isin(interesting_mails["msg_id"])]

    strongly_ambiguous_mails = interesting_mails[interesting_mails["strongly_agressive_votes"] >= 2]
    print("Aggressiveness ratings:")
    print(f"-- not mdly stly   total -----------------------")
    for index, row in strongly_ambiguous_mails.iterrows():       
        print(f"--   {row['not_agressive_votes']} +  {row['mildly_agressive_votes']} +  {row['strongly_agressive_votes']} = {row['ratings']} ---------------------------")
        print(row["msg_id"])
        print(row["Content"])
        print()

def plot_aggression_rating_trend():
    # enable TeX
    plt.rcParams['text.usetex'] = True

    # Now read and process the annotation data.
    first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
    second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")
      
    first_batch_data = first_batch_data[first_batch_data["corrupted"] == 0]
    first_batch_data = first_batch_data[first_batch_data["spam"] == 0]
    first_batch_data = first_batch_data[first_batch_data["auto_generated"] == 0]

    second_batch_data = second_batch_data[second_batch_data["corrupted"] == 0]
    second_batch_data = second_batch_data[second_batch_data["spam"] == 0]
    second_batch_data = second_batch_data[second_batch_data["auto_generated"] == 0]

    first_batch_data["aggressive_votes"] = first_batch_data.apply(lambda x : 1 if x["label"] < 0 else 0, axis = 1)
    first_batch_data["ratings"] = first_batch_data.apply(lambda x : 0, axis = 1)
    second_batch_data["aggressive_votes"] = second_batch_data.apply(lambda x : 1 if x["label"] < 0 else 0, axis = 1)
    second_batch_data["ratings"] = second_batch_data.apply(lambda x : 0, axis = 1)

    first_batch_data = first_batch_data.groupby(by = "msg_id").agg({
        "ratings" : "count",
        "aggressive_votes" : "sum",
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
        "meta" : "sum"
    })
    second_batch_data = second_batch_data.groupby(by = "msg_id").agg({
        "ratings" : "count",
        "aggressive_votes" : "sum",
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
        "meta" : "sum"
    })
    first_batch_data["not_none"] = (
        first_batch_data["target_technical"] + 
        first_batch_data["target_recipient"] + 
        first_batch_data["target_thirdparty"] + 
        first_batch_data["target_self"] +
        first_batch_data["target_other"] +
        first_batch_data["target_quoted"])
    second_batch_data["not_none"] = (
        second_batch_data["target_technical"] + 
        second_batch_data["target_recipient"] + 
        second_batch_data["target_thirdparty"] + 
        second_batch_data["target_self"] +
        second_batch_data["target_other"] +
        second_batch_data["target_quoted"])
    first_batch_data["none"] = first_batch_data["target_none"]
    second_batch_data["none"] = second_batch_data["target_none"]

    unsure_msg_ids = unsure_mail_ids["msg_id"].tolist()
    ambiguous_msg_ids = get_interesting_unsure_mails()["msg_id"].tolist()

    first_batch_unsure = []
    second_batch_unsure = []
    first_batch_ambiguous = []
    second_batch_ambiguous = []

    for i in range(len(first_batch_data)):
        mail = first_batch_data.iloc[i]

        if mail.name in ambiguous_msg_ids:
            first_batch_ambiguous.append((i, mail))
        elif mail.name in unsure_msg_ids:
            first_batch_unsure.append((i, mail))

    for i in range(len(second_batch_data)):
        mail = second_batch_data.iloc[i]

        if mail.name in ambiguous_msg_ids:
            second_batch_ambiguous.append((i, mail))
        elif mail.name in unsure_msg_ids:
            second_batch_unsure.append((i, mail))

    x_first = list(range(0, len(first_batch_data)))
    x_first_unsure = list(map(lambda t : t[0], first_batch_unsure))
    x_first_ambiguous = list(map(lambda t : t[0], first_batch_ambiguous))
    x_second = list(range(0, len(second_batch_data)))
    x_second_unsure = list(map(lambda t : t[0], second_batch_unsure))
    x_second_ambiguous = list(map(lambda t : t[0], second_batch_ambiguous))

    y_first_unsure = list(map(lambda t : t[1], first_batch_unsure))
    y_first_ambiguous = list(map(lambda t : t[1], first_batch_ambiguous))
    y_second_unsure = list(map(lambda t : t[1], second_batch_unsure))
    y_second_ambiguous = list(map(lambda t : t[1], second_batch_ambiguous))

    # ----------------------------------------------------------------------------
    # Aggression
    # first batch
    
    y = (first_batch_data["aggressive_votes"] / first_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.aggressive_votes / x.ratings , y_first_unsure))
    y_ambiguous = list(map(lambda x : x.aggressive_votes / x.ratings , y_first_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_first, y)

    plt.figure(figsize=(20,10))
    plt.title("Relative number of aggressive votings to all ratings per mail (First batch)")
    # plt.text(1, 0.9, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_first, y, "o", label = "Mails where raters agreed")
    plt.plot(x_first_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_first_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)    
    plt.xlabel("Mails in temporal rating order (first batch)")
    plt.ylabel(r"$\frac{\#~aggr.~ratings}{\#~total~ratings}$", rotation = 0, labelpad = 15)
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_aggression_first_batch.svg")

    # second batch
    y = (second_batch_data["aggressive_votes"] / second_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.aggressive_votes / x.ratings , y_second_unsure))
    y_ambiguous = list(map(lambda x : x.aggressive_votes / x.ratings , y_second_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_second, y)

    plt.figure(figsize=(20,10))
    plt.title("Relative number of aggressive votings to all ratings per mail (Second batch)")
    # plt.text(1, 0.9, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_second, y, "o", label = "Mails where raters agreed")
    plt.plot(x_second_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_second_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)
    plt.xlabel("Mails in temporal rating order (second batch)")
    plt.ylabel(r"$\frac{\#~aggr.~ratings}{\#~total~ratings}$", rotation = 0, labelpad = 15)
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_aggression_second_batch.svg")

    # ----------------------------------------------------------------------------
    # Targets
    # None 
    # first batch
    y = (first_batch_data["none"] / first_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.none / x.ratings , y_first_unsure))
    y_ambiguous = list(map(lambda x : x.none / x.ratings , y_first_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_first, y)

    plt.figure(figsize=(20,10))
    plt.title("Relative number of 'none' target votings to all ratings per mail (First batch)")
    # plt.text(1, 0.1, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_first, y, "o", label = "Mails where raters agreed")
    plt.plot(x_first_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_first_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)
    plt.xlabel("Mails in temporal rating order (first batch)")
    plt.ylabel(r"$\frac{\#~target~none}{\#~total~ratings}$", rotation = 0, labelpad = 15)  
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_target_none_first_batch.svg")

    # second batch
    y = (second_batch_data["none"] / second_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.none / x.ratings , y_second_unsure))
    y_ambiguous = list(map(lambda x : x.none / x.ratings , y_second_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_second, y)
    
    plt.figure(figsize=(20,10))
    plt.title("Relative number of 'none' target votings to all ratings per mail (Second batch)")
    # plt.text(1, 0.1, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_second, y, "o", label = "Mails where raters agreed")
    plt.plot(x_second_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_second_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)
    plt.xlabel("Mails in temporal rating order (second batch)")
    plt.ylabel(r"$\frac{\#~target~none}{\#~total~ratings}$", rotation = 0, labelpad = 15)  
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_target_none_second_batch.svg")

    # ----------------------------------------------------------------------------
    # Not none 
    # first batch
    y = (first_batch_data["not_none"] / first_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.not_none / x.ratings , y_first_unsure))
    y_ambiguous = list(map(lambda x : x.not_none / x.ratings , y_first_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_first, y)

    plt.figure(figsize=(20,10))
    plt.title("Relative number of target votings (not 'none') to all ratings per mail (First batch)")
    # plt.text(1, 1.85, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_first, y, "o", label = "Mails where raters agreed")
    plt.plot(x_first_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_first_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)
    plt.xlabel("Mails in temporal rating order (first batch)")
    plt.ylabel(r"$\frac{\sum~targets~not~none}{\#~total~ratings}$", rotation = 0, labelpad = 20)    
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_target_not_none_first_batch.svg")

    # second batch
    y = (second_batch_data["not_none"] / second_batch_data["ratings"]).tolist()
    y_unsure = list(map(lambda x : x.not_none / x.ratings , y_second_unsure))
    y_ambiguous = list(map(lambda x : x.not_none / x.ratings , y_second_ambiguous))

    # slope, intercept, r_value, p_value, std_err = linregress(x_second, y)

    plt.figure(figsize=(20,10))
    plt.title("Relative number of target votings (not 'none') to all ratings per mail (Second batch)")
    # plt.text(1, 1.6, f'r-value: {r_value:5.4f}, p-value: {p_value:5.4f}', bbox={'facecolor': 'white', 'alpha': 0.5, 'pad': 10})
    # plt.axline(xy1 = (0, intercept), slope = slope, linestyle = "--", color = "k", label = "Regression line")
    plt.plot(x_second, y, "o", label = "Mails where raters agreed")
    plt.plot(x_second_ambiguous, y_ambiguous, "D", label = "Ambiguous mails", markersize = 7)
    plt.plot(x_second_unsure, y_unsure, "s", label = "Unsure but not ambiguos mails", markersize = 7)
    plt.xlabel("Mails in temporal rating order (second batch)")
    plt.ylabel(r"$\frac{\sum~targets~not~none}{\#~total~ratings}$", rotation = 0, labelpad = 20)     
    plt.legend()
    # plt.show()
    plt.savefig("plots/lin_regr_target_not_none_second_batch.svg")

    # disable TeX
    plt.rcParams['text.usetex'] = False

def write_mails_to_file_pretty():
    unsure_mails = get_unsure_mails()

    s  = "# Qualitative evaluation\n"
    s += "Below, for each of the 92 unsure mails the content and the meta data is printed. A comment tries to explain how one could interpret the mail such that the deifferent votings become plausible.\n\n"
    s += "*Classification:*\n\n"
    s += "- *ambiguous:* mails which fulfill the condition no. of targets human + technical $\geq$ no. of aggressive votes\n"
    s += "- *unsure:* All other unsure mails"
    s += "\n"
    i = 1

    for id, mail in unsure_mails.iterrows():
        s += f"## Mail {i}\n\n"
        s += f"From '{mail.From_name}'\n\n"
        s += f"**Ratings:** {mail.ratings}  -  Aggr./not aggr.: {mail.agressive_votes} / {mail.not_agressive_votes}\n\n"
        s += f"**Targets:** human = {mail.target_self + mail.target_recipient + mail.target_thirdparty}, technical = {mail.target_technical}, other = {mail.target_other + mail.target_quoted}, none = {mail.target_none}\n\n"
        s += f"**Classification:** {'unsure' if mail.target_technical + mail.target_self + mail.target_recipient + mail.target_thirdparty < mail.agressive_votes else 'ambiguous'}\n\n"
        s += "\n"
        for l in mail.Content_x.split("\n"):
            s += f"> {l}"
        s += "\n\n"
        s += "#### Comment\n\n-\n\n"
        i += 1

    with open("qualitative_eval/dump.md", "w") as f:
        f.write(s)

def eval_qualitative_analysis():
    filename = "qualitative_eval/comments.md"
    category_string = "**category:** "
    category_context_missing = category_string + "missing context"
    category_dont_know = category_string + "don't know"
    category_unsure = category_string + "unsure"
    category_constructive = category_string + "constructive"
    category_swear_words = category_string + "swear words"
    category_tone = category_string + "tone"

    with open(filename, "r") as f:
        text = f.read().lower()

        count_context_missing = text.count(category_context_missing)
        count_dont_know = text.count(category_dont_know)
        count_unsure = text.count(category_unsure)
        count_constructive = text.count(category_constructive)
        count_swear_words = text.count(category_swear_words)
        count_tone = text.count(category_tone)

        # Sanity check. Should both print "92"
        # print((
        #     count_context_missing +
        #     count_tone + 
        #     count_swear_words +
        #     count_constructive + 
        #     count_unsure + 
        #     count_dont_know
        # ))
        # print(text.count(category_string))

        fig, ax = plt.subplots(figsize=(14,8))    
        plt.title("Distribution of most likely causes for a mail\nto be ambiguous (based on manual investigation)")

        y = [count_tone, count_swear_words, count_constructive, count_context_missing, count_dont_know]
        x = ["Tone", "Swear words", "Constructive", "Context missing", "Don't know"]

        ax.bar(x, y, label = "Number of mails (Total 76)")

        s = """        
        The comments can be further summarized into certain categories that try to define the cause of the 
        discrepancy between the number of targets and aggressive votes:
        - Tone: When the cause of the discrepancy is most likely due to the mail having an attacking tone 
          without any swear words.
        - Swear words: When the cause of the discrepancy is most likely due to swear words that are perceived 
          non-aggressive (ironic, funny), sometimes also with regards to technical stuff. Also includes e.g. 
          ALL CAPS sentences as they mostly perceived as screaming.
        - Constructive: When the cause of the discrepancy is most likely due to a very constructive 
          tone of the mail despite also containing clear aggression or attack against somebody.
        - Missing context: When the cause of the discrepancy is most likely to be caused by the lack of 
          context due to preprocessing (removeing quotes, previous mails, etc.).
        - Don't know: The cause couldn't be determined.
        """

        for i in range(len(x)):
            ax.text(i, y[i] + 1, y[i], ha = 'center') # paper version: , fontsize = 19)

        # with box
        props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
        plt.ylim(0, 80)
        ax.text(-0.5, 77, s, verticalalignment='top', bbox=props)

        # without box (paper version)
        # plt.ylim(0, 35) 
        # for item in ([ax.title, ax.xaxis.label, ax.yaxis.label] +
        #     ax.get_xticklabels() + ax.get_yticklabels() + ax.legend().get_texts()):
        #     item.set_fontsize(19)       
        

        ax.legend()
        # plt.show()

        plt.savefig("plots/ambiguous-mails-qualitative-eval.svg")

# plot_aggression_rating_trend()

plot_inter_rater_agreement(False)
# plot_target_distribution()
# plot_none_distribution()

# print_strongly_ambiguous_mails()

# plot_author_distribution(get_interesting_unsure_mails())
# plot_author_distribution(get_all_mails())

# plot_interesting_unsure_mails_agression_distinction()

# write_mails_to_file_pretty()

eval_qualitative_analysis()