#from lkml_preprocessing_html import generate_html_comparison_from_files
#from lkml_mail_preprocessing import process_text
#from utils.utils import generate_preprocessed_datasets
import os
import pandas as pd
from utils.label_mapping import get_final_labels, map_single_labels
from utils.combine_results_of_both_prestudies import combine_results_of_both_prestudies
from tools.perspective import evaluate_all_datasets as evaluate_all_datasets_perspective
from tools.vader import evaluate_all_datasets as evaluate_all_datasets_vader
from tools.stanford import evaluate_all_datasets as evaluate_all_datasets_stanford
from tools.sentistrength_se import evaluate_all_datasets as evaluate_all_datasets_sentistrength
from tools.comparison import calculate_binary_tool_agreement
from utils.rater_agreement import calculate_and_print_icc_and_krippendoffs_alphas

## GET ANNOTATION RESULTS

# Batch 1

path = "annotations_batch1.csv"
map_single_labels(path, write_output=True, outfile="single_mapped_labels.csv")
get_final_labels(path, True, True, "final_batch_labels.csv")
get_final_labels(path, True, True, "final_batch_labels.csv", mode="aggressive_if_one_is_aggressive")
get_final_labels(path, True, True, "final_batch_labels.csv", mode="all_but_one_agree")

# Batch 2

path = "annotations_batch2.csv"
map_single_labels(path, write_output=True, outfile="single_mapped_labels2.csv")
get_final_labels(path, True, True, "final_batch_labels2.csv")
get_final_labels(path, True, True, "final_batch_labels2.csv", mode="aggressive_if_one_is_aggressive")
get_final_labels(path, True, True, "final_batch_labels2.csv", mode="all_but_one_agree")

# Combine batch results

os.chdir("tools")
combine_results_of_both_prestudies()
combine_results_of_both_prestudies(mode="aggressive_if_one_is_aggressive")
combine_results_of_both_prestudies(mode="all_but_one_agree")


## EVALUATE TOOLS

result_perspective = evaluate_all_datasets_perspective()
result_vader = evaluate_all_datasets_vader()
result_stanford = evaluate_all_datasets_stanford()
result_sentistrength = evaluate_all_datasets_sentistrength()

result_perspective = evaluate_all_datasets_perspective(mode="aggressive_if_one_is_aggressive")
result_vader = evaluate_all_datasets_vader(mode="aggressive_if_one_is_aggressive")
result_stanford = evaluate_all_datasets_stanford(mode="aggressive_if_one_is_aggressive")
result_sentistrength = evaluate_all_datasets_sentistrength(mode="aggressive_if_one_is_aggressive")

result_perspective = evaluate_all_datasets_perspective(mode="all_but_one_agree")
result_vader = evaluate_all_datasets_vader(mode="all_but_one_agree")
result_stanford = evaluate_all_datasets_stanford(mode="all_but_one_agree")
result_sentistrength = evaluate_all_datasets_sentistrength(mode="all_but_one_agree")

## TOOL AGREEMENT

calculate_binary_tool_agreement(tools=['VADER','perspective','stanford','sentistrength'])

## INTERRATER AGREEMENT

# Install package ICC:
#import rpy2.robjects.packages as rpackages
#utils = rpackages.importr('utils')
#utils.chooseCRANmirror(ind=1)
#from rpy2.robjects.vectors import StrVector
#utils.install_packages("ICC")

path_single_labels_1 = "../single_mapped_labels.csv"
path_single_labels_2 = "../single_mapped_labels2.csv"

df_single_labels_1 = pd.read_csv(path_single_labels_1, sep=";")
df_single_labels_2 = pd.read_csv(path_single_labels_2, sep=";")

# drop email_id column as this id is not unique across both data sets
df_single_labels_1 = df_single_labels_1.drop("email_id", axis=1)
df_single_labels_2 = df_single_labels_2.drop("email_id", axis=1)

df_single_labels = pd.concat([df_single_labels_1, df_single_labels_2], ignore_index = True)

print("\nall:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels)

# only male:
print("\nonly male:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [16,24,27,29,30,32])

# only female:
print("\nonly female:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [14,15,28,31])

# no OSS:
print("\nno OSS:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [28,29,30,32])

# at least one OSS
print("\nat least one OSS:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [14,15,16,24,27,31])

# <= 2 OSS
print("\n<= 2 OSS:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [14,15,28,29,30,31,32])

# > 2 OSS
print("\n> 2 OSS")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [16,24,27])

# experience 1-5
print("\nexperience 1-5:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [14,28,29,31])

# experience 6-10
print("\nexperience 6-10:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [15,16,24,27,30,32])

# experience-compared 1-2
print("\nexperience compared 1-2:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [14,29,30])

# experience-compared 3-5
print("\nexperience compared 3-5:")
calculate_and_print_icc_and_krippendoffs_alphas(df_single_labels, users = [15,16,24,27,28,31,32])


