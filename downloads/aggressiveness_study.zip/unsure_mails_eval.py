import pandas as pd
import numpy as np
import re
from scipy.stats import pearsonr, spearmanr

def get_unsure_mail_data(out_path = "unsure_mails_with_agg_data.csv", unsure_mails_file = "unsure_emails.csv", 
                         processing_level = 4, excldue_unsure_ratings = False):
    '''
    Build a data frame containing accumulated ratings as well as the mail content itself for the unsure mails.
    out_path:               The file that the data is being written to in order to speed up the analysis.
    unsure_mails_file:      The file containing the ids of the questionable mails that was produced by the 
                            "find_unsure_mails.py" script.
    processing_level:       A number from 1 to 4 indicating which level of preprocessing the mail content in the data frame
                            should have. For the concrete meanings refer to the README.
    excldue_unsure_ratings: If True, only ratings are accumulated if the feature "not_sure" has the value 0. Else, every rating
                            is considered.    
    '''
    # Set the processing level according to the file names.
    if processing_level == 1:
        processing_level = "1_minimal"
    elif processing_level == 2:
        processing_level = "2_simple"
    elif processing_level == 3:
        processing_level = "3_advanced"    
    elif processing_level == 4:
        processing_level = "4_maximal"

    # Read the unsure mail data.
    unsure_mails = pd.read_csv(unsure_mails_file, sep=",")

    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails])

    # Now read and process the annotation data.
    first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
    second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")
   
    # Aggregate the important data over all annotations.
    all_data = pd.concat([first_batch_data, second_batch_data])
    # If configured, exclude all ratings that are labelled as not sure.

    if excldue_unsure_ratings:
        all_data = all_data[all_data["not_sure"] == 0]
    
    all_data = all_data.groupby(by = "msg_id").agg({
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
        "meta" : "sum",
    })

    # Now merge the three data frames on the msg_id
    content_rating = pd.merge(unsure_mails, all_mails, on = "Message_id", how = "inner").rename(columns={"Message_id" : "msg_id"})
    data = pd.merge(content_rating, all_data, on = "msg_id", how = "inner")

    # Add columns that count word length and char length of the mails.
    data['mail_length_words'] =  data["Content"].apply(lambda c : len(re.split("\s+", c)))
    data['mail_length_chars'] =  data["Content"].apply(lambda c : len(c))
    data.to_csv(out_path, sep = ";")
    # return only valid rows.
    return data[data["agressive_votes"] + data["not_agressive_votes"] == data["ratings"]] 

def get_all_mail_data(out_path = "complete_mails_with_agg_data.csv", processing_level = 4,
                        excldue_unsure_ratings = False):
    '''
    Build a data frame containing accumulated ratings as well as the mail content itself for every mail.
    out_path:               The file that the data is being written to in order to speed up the analysis.
    unsure_mails_file:      The file containing the ids of the questionable mails that was produced by the 
                            "find_unsure_mails.py" script.
    processing_level:       A number from 1 to 4 indicating which level of preprocessing the mail content in the data frame
                            should have. For the concrete meanings refer to the README.
    excldue_unsure_ratings: If True, only ratings are accumulated if the feature "not_sure" has the value 0. Else, every rating
                            is considered.
    '''
    # Set the processing level according to the file names.
    if processing_level == 1:
        processing_level = "1_minimal"
    elif processing_level == 2:
        processing_level = "2_simple"
    elif processing_level == 3:
        processing_level = "3_advanced"    
    elif processing_level == 4:
        processing_level = "4_maximal"

    # Read and merge the contents of all mails.
    first_batch_mails = pd.read_csv(f"batch_2019-10-18_{processing_level}_processing.csv", sep=",")    
    second_batch_mails = pd.read_csv(f"batch_2019-04-15_{processing_level}_processing.csv", sep=",")
    all_mails = pd.concat([first_batch_mails, second_batch_mails]).rename(columns={"Message_id" : "msg_id"})

    # Now read and process the annotation data.
    first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
    second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")
   
    # Aggregate the important data over all annotations.
    all_data = pd.concat([first_batch_data, second_batch_data])
    
    all_data = all_data[all_data["corrupted"] == 0]
    all_data = all_data[all_data["spam"] == 0]
    all_data = all_data[all_data["auto_generated"] == 0]
    # If configured, exclude all ratings that are labelled as not sure.
    
    if excldue_unsure_ratings:
        all_data = all_data[all_data["not_sure"] == 0]

    # Add column according to the label (1 = agressive, 0 = not agressive).
    all_data["agressive_votes"] = all_data.apply(lambda x : 1 if x["label"] < 0 else 0, axis = 1)
    all_data["ratings"] = all_data.apply(lambda x : 0, axis = 1)

    all_data = all_data.groupby(by = "msg_id").agg({
        "ratings" : "count",
        "agressive_votes" : "sum",
        "target_recipient" : "sum",
        "target_thirdparty" : "sum",
        "target_technical" : "sum",
        "target_self" : "sum",
        "target_quoted" : "sum",
        "target_other" : "sum",
        "target_none" : "sum",
        "meta" : "sum"
    })

    all_data["not_agressive_votes"] = all_data.apply(lambda x : x["ratings"] - x["agressive_votes"], axis = 1)
  
    data = pd.merge(all_mails, all_data, on = "msg_id", how = "inner")
    
    # Add columns that count word length and char length of the mails.
    data['mail_length_words'] = data["Content"].apply(lambda c : len(re.split("\s+", str(c))))
    data['mail_length_chars'] =  data["Content"].apply(lambda c : len(str(c)))
    data.to_csv(out_path, sep = ";")
    # return only valid rows.
    return data[data["agressive_votes"] + data["not_agressive_votes"] == data["ratings"]] 

def separate_mails_by_median(data, upper):
    '''
    Separates a data frame produced by the two methods above by te median of the number of words in the mails.
    If "upper" is set to "True", return the mails above the median, else the ones below.
    '''
    m = data["mail_length_words"].median(0)
    return data[data["mail_length_words"] > m if upper else data["mail_length_words"] <= m]

def get_mails_with_only_target_technical(data):
    '''
    Was intended to find mails in a data frame that only are rated as "target_technical" but there were none such mails.
    Even with the lines commented only two mails were left which was considered not helpful.
    '''
    data = data[data["target_technical"] > 0]
    data = data[data["target_recipient"] == 0]
    data = data[data["target_thirdparty"] == 0]
    # data = data[data["target_self"] == 0]
    # data = data[data["target_other"] == 0]
    # data = data[data["target_quoted"] == 0]
    data = data[data["target_none"] == 0]

    return data

def separate_mails_with_respect_to_target_technical(split_data, data):
    '''
    Was intended to split the mails into three groups: 
    - Mails I rated with "target_technical" that have at least one "target_technical" rating in the actual data 
      (matching_mails_positive).
    - Mails I did not rate with "target_technical" that also have no "target_technical" rating in the actual data
      (matching_mails_negative).
    - The rest that doesn't match.
    split_data: The database export of my annotations of the 92 unsure mails.
    data: The unsre mail data frame (the result of get_unsure_mail_data()).
    '''
    split_data_with_technical = split_data[split_data["target_technical"] > 0]
    split_data_without_technical = split_data[split_data["target_technical"] == 0]

    matching_mails_positive = data[data["msg_id"].isin(split_data_with_technical["msg_id"])]
    matching_mails_positive = matching_mails_positive[matching_mails_positive["target_technical"] > 0]
    
    matching_mails_negative = data[data["msg_id"].isin(split_data_without_technical["msg_id"])]
    matching_mails_negative = matching_mails_negative[matching_mails_negative["target_technical"] == 0]

    return matching_mails_positive, matching_mails_negative

def show_target_occurence(data, target):
    '''
    Experimental function to draw a histogram of any column of a dataframe.
    '''
    plt.hist(data[f'target_{target}'])
    plt.show()



def compute_correlation_to_aggressive_ratings_pearson(data):
    '''
    Compute the Pearson correlation coefficient and p-value between the number of aggressive votings and ratings per 
    feature relatively to the number of ratings of a mail.
    '''
    corr_agr_target_technical = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_technical'] / data["ratings"]))
    corr_agr_target_recipient = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_recipient'] / data["ratings"]))
    corr_agr_target_self = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_self'] / data["ratings"]))
    corr_agr_target_none = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_none'] / data["ratings"]))
    corr_agr_target_thirdparty = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_thirdparty'] / data["ratings"]))
    corr_agr_target_quoted = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_quoted'] / data["ratings"]))
    corr_agr_target_other = pearsonr((data['agressive_votes'] / data["ratings"]), (data['target_other'] / data["ratings"]))
    corr_agr_target_meta = pearsonr((data['agressive_votes'] / data["ratings"]), (data['meta'] / data["ratings"]))

    corr_agr_length_words = pearsonr((data['agressive_votes'] / data["ratings"]), data['mail_length_words'])

    return corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words

def compute_correlation_to_aggressive_ratings_spearman(data):
    '''
    Compute the Spearman correlation coefficient and p-value between the number of aggressive votings and ratings per 
    feature relatively to the number of ratings of a mail.
    '''
    corr_agr_target_technical = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_technical'] / data["ratings"]))
    corr_agr_target_recipient = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_recipient'] / data["ratings"]))
    corr_agr_target_self = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_self'] / data["ratings"]))
    corr_agr_target_none = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_none'] / data["ratings"]))
    corr_agr_target_thirdparty = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_thirdparty'] / data["ratings"]))
    corr_agr_target_quoted = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_quoted'] / data["ratings"]))
    corr_agr_target_other = spearmanr((data['agressive_votes'] / data["ratings"]), (data['target_other'] / data["ratings"]))
    corr_agr_target_meta = spearmanr((data['agressive_votes'] / data["ratings"]), (data['meta'] / data["ratings"]))
    corr_agr_length_words = spearmanr((data['agressive_votes'] / data["ratings"]), data['mail_length_words'])

    return corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words

def compute_correlation_to_word_length_pearson(data):
    '''
    Compute the Pearson correlation coefficient and p-value between the number of words in a mail and ratings per 
    feature relatively to the number of ratings of a mail.
    '''
    corr_word_target_technical = pearsonr(data['mail_length_words'], data['target_technical'] / data["ratings"])
    corr_word_target_recipient = pearsonr(data['mail_length_words'], data['target_recipient'] / data["ratings"])
    corr_word_target_self = pearsonr(data['mail_length_words'], data['target_self'] / data["ratings"])
    corr_word_target_none = pearsonr(data['mail_length_words'] , data['target_none'] / data["ratings"])
    corr_word_target_thirdparty = pearsonr(data['mail_length_words'], data['target_thirdparty'] / data["ratings"])
    corr_word_target_quoted = pearsonr(data['mail_length_words'], data['target_quoted'] / data["ratings"])
    corr_word_target_other = pearsonr(data['mail_length_words'], data['target_other'] / data["ratings"])
    corr_word_target_meta = pearsonr(data['mail_length_words'], data['meta'] / data["ratings"])
    corr_word_ratings = pearsonr(data['mail_length_words'], data['agressive_votes'])

    return corr_word_target_recipient, corr_word_target_technical, corr_word_target_self, corr_word_target_none, corr_word_target_thirdparty, corr_word_target_quoted, corr_word_target_other, corr_word_target_meta, corr_word_ratings

def compute_correlation_to_word_length_spearman(data):
    '''
    Compute the Spearman correlation coefficient and p-value between the number of words in a mail and ratings per 
    feature relatively to the number of ratings of a mail.
    '''
    corr_word_target_technical = spearmanr(data['mail_length_words'], data['target_technical'] / data["ratings"])
    corr_word_target_recipient = spearmanr(data['mail_length_words'], data['target_recipient'] / data["ratings"])
    corr_word_target_self = spearmanr(data['mail_length_words'], data['target_self'] / data["ratings"])
    corr_word_target_none = spearmanr(data['mail_length_words'], data['target_none'] / data["ratings"])
    corr_word_target_thirdparty = spearmanr(data['mail_length_words'], data['target_thirdparty'] / data["ratings"])
    corr_word_target_quoted = spearmanr(data['mail_length_words'], data['target_quoted'] / data["ratings"])
    corr_word_target_other = spearmanr(data['mail_length_words'], data['target_other'] / data["ratings"])
    corr_word_target_meta = spearmanr(data['mail_length_words'], data['meta'] / data["ratings"])

    corr_word_ratings = spearmanr(data['mail_length_words'], data['agressive_votes'] / data["ratings"])

    return corr_word_target_recipient, corr_word_target_technical, corr_word_target_self, corr_word_target_none, corr_word_target_thirdparty, corr_word_target_quoted, corr_word_target_other, corr_word_target_meta, corr_word_ratings



def print_pearson_result_agr(data, name, p = False):
    '''
    Print the Pearson result (compute_correlation_to_aggressive_ratings_pearson) neatly to the console.
    '''
    corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words = compute_correlation_to_aggressive_ratings_pearson(data)

    print(f"Pearson test - {name}:")

    if p:
        print(f"{corr_agr_target_recipient[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_technical[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_self[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_none[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_quoted[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_other[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_meta[1]:10e}".replace(".", ","))
        print(f"{corr_agr_length_words[1]:10e}".replace(".", ","))
    else:
        print(f"{corr_agr_target_recipient[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_technical[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_self[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_none[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_quoted[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_other[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_meta[0]:10f}".replace(".", ","))
        print(f"{corr_agr_length_words[0]:10f}".replace(".", ","))

def print_spearman_result_agr(data, name, p = False):
    '''
    Print the Spearman result (compute_correlation_to_aggressive_ratings_spearman) neatly to the console.
    '''
    corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words = compute_correlation_to_aggressive_ratings_spearman(data)

    print(f"Spearman test - {name}:")

    if p:
        print(f"{corr_agr_target_recipient[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_technical[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_self[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_none[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_quoted[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_other[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_meta[1]:10e}".replace(".", ","))
        print(f"{corr_agr_length_words[1]:10e}".replace(".", ","))
    else:
        print(f"{corr_agr_target_recipient[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_technical[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_self[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_none[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_quoted[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_other[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_meta[0]:10f}".replace(".", ","))
        print(f"{corr_agr_length_words[0]:10f}".replace(".", ","))

def print_pearson_result_words(data, name, p = False):
    '''
    Print the Pearson result (compute_correlation_to_word_length_pearson) neatly to the console.
    '''
    corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words = compute_correlation_to_word_length_pearson(data)

    print(f"Pearson test - {name}:")

    if p:
        print(f"{corr_agr_target_recipient[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_technical[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_self[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_none[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_quoted[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_other[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_meta[1]:10e}".replace(".", ","))
        print(f"{corr_agr_length_words[1]:10e}".replace(".", ","))
    else:
        print(f"{corr_agr_target_recipient[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_technical[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_self[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_none[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_quoted[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_other[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_meta[0]:10f}".replace(".", ","))
        print(f"{corr_agr_length_words[0]:10f}".replace(".", ","))

def print_spearman_result_words(data, name, p = False):
    '''
    Print the Spearman result (compute_correlation_to_word_length_spearman) neatly to the console.
    '''
    corr_agr_target_recipient, corr_agr_target_technical, corr_agr_target_self, corr_agr_target_none, corr_agr_target_thirdparty, corr_agr_target_quoted, corr_agr_target_other, corr_agr_target_meta, corr_agr_length_words = compute_correlation_to_word_length_spearman(data)

    print(f"Spearman test - {name}:")
    
    if p:
        print(f"{corr_agr_target_recipient[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_technical[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_self[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_none[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_quoted[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_other[1]:10e}".replace(".", ","))
        print(f"{corr_agr_target_meta[1]:10e}".replace(".", ","))
        print(f"{corr_agr_length_words[1]:10e}".replace(".", ","))
    else:
        print(f"{corr_agr_target_recipient[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_technical[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_self[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_none[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_thirdparty[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_quoted[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_other[0]:10f}".replace(".", ","))
        print(f"{corr_agr_target_meta[0]:10f}".replace(".", ","))
        print(f"{corr_agr_length_words[0]:10f}".replace(".", ","))



def get_unsure_data(filename, comments_only = False):
    '''
    Read the unsure mail file that was produced by the script "find_unsure_mails.py" and turn it into
    a data frame containing the necessary information for further processing.
    '''
    # Read the unsure mail data.
    unsure_mails = pd.read_csv("unsure_emails.csv", sep=",").rename(columns={"Message_id" : "msg_id"})

    # Now read and process the annotation data.
    first_batch_data = pd.read_csv(f"single_mapped_labels.csv", sep=";")    
    second_batch_data = pd.read_csv(f"single_mapped_labels2.csv", sep=";")
   
    # Aggregate the important data over all annotations.
    all_data = pd.concat([first_batch_data, second_batch_data])
    # If configured, exclude all ratings that are labelled as not sure.

    data = pd.merge(unsure_mails, all_data, on = "msg_id", how = "inner")

    if comments_only:        
        data = data[~pd.isna(data["comment"])]
        
    data.to_csv(filename)
    return data

def write_mails_and_comments():
    '''
    For each (unsure) mail rating that has a comment that is not empty, creates a file with the mail content and the comment
    for further investiagtion.
    '''
    ids_annotations_with_comments = get_unsure_data("unsure_mails_only_comments.csv", True)[["msg_id", "comment"]]
    mails_with_comments = pd.merge(ids_annotations_with_comments, data_unsure, on = "msg_id")[["msg_id", "Content", "comment"]]

    mails_with_comments = mails_with_comments.set_index("msg_id")

    for id, row in mails_with_comments.iterrows():
        name = id.replace("<", "").replace(">", "").replace("@", "_at_")
        with open(f"comment_eval/mail_{name}.txt", "w") as f:
            f.write(f"{row['comment']}\n\n---------------------------------------------------------------\n\n{row['Content']}")


# Start of analysis: Load data. If the files are not present, run the first two lines, else the read_csv is enough.
data_unsure = get_unsure_mail_data(excldue_unsure_ratings=True)
data_complete = get_all_mail_data(excldue_unsure_ratings=True)
data_unsure = pd.read_csv("unsure_mails_with_agg_data.csv", sep = ";") 
data_complete = pd.read_csv("complete_mails_with_agg_data.csv", sep = ";") 

# Get the rows of data_complete that are not unsure mails.
common = data_complete.merge(data_unsure, on=["msg_id"])
data_difference = data_complete[~data_complete["msg_id"].isin(common["msg_id"])]

# Print the simple correlation results for the three groups of mails (Excel: 1st and 4th sheet).
#   The 1st sheet refers to all ratings (calling get_all_mail_data / get_unsure_mail_data with 
#   excldue_unsure_ratings = False), the 4th sheet consideres only ratings not labelled "not_sure"
#   (calling the above methods with excldue_unsure_ratings = True).
#   This also holds for the 2 other correlation steps below.
# print_pearson_result_agr(data_complete, "Complete mails", True)
# print_spearman_result_agr(data_complete, "Complete mails", True)
# print_pearson_result_agr(data_unsure, "Unsure mails", True)
# print_spearman_result_agr(data_unsure, "Unsure mails", True)
# print_pearson_result_agr(data_difference, "Difference", True)
# print_spearman_result_agr(data_difference, "Difference", True)

# Split the data by the median of the number of words per mail for each group.
# data_complete_length_median_upper = separate_mails_by_median(data_complete, True)
# data_complete_length_median_lower = separate_mails_by_median(data_complete, False)
# data_unsure_length_median_upper = separate_mails_by_median(data_unsure, True)
# data_unsure_length_median_lower = separate_mails_by_median(data_unsure, False)
# data_difference_length_median_upper = separate_mails_by_median(data_difference, True)
# data_difference_length_median_lower = separate_mails_by_median(data_difference, False)

# Print the correlation results for the separation by the median of the number of words (Excel: 2nd and 4th sheet).
# print_pearson_result_agr(data_complete_length_median_lower, "Complete mails | word length < median", True)
# print_spearman_result_agr(data_complete_length_median_lower, "Complete mails | word length < median", True)
# print_pearson_result_agr(data_complete_length_median_upper, "Complete mails | word length > median", True)
# print_spearman_result_agr(data_complete_length_median_upper, "Complete mails | word length > median", True)

# print_pearson_result_agr(data_unsure_length_median_lower, "Unsure mails | word length < median", True)
# print_spearman_result_agr(data_unsure_length_median_lower, "Unsure mails | word length < median", True)
# print_pearson_result_agr(data_unsure_length_median_upper, "Unsure mails | word length > median", True)
# print_spearman_result_agr(data_unsure_length_median_upper, "Unsure mails | word length > median", True)

# print_pearson_result_agr(data_difference_length_median_lower, "Difference mails | word length < median", True)
# print_spearman_result_agr(data_difference_length_median_lower, "Difference mails | word length < median", True)
# print_pearson_result_agr(data_difference_length_median_upper, "Difference mails | word length > median", True)
# print_spearman_result_agr(data_difference_length_median_upper, "Difference mails | word length > median", True)

# Print the correlation results for the number of words (Excel: 3rd and 6th sheet).
# print_pearson_result_words(data_complete, "Complete mails", False)
# print_spearman_result_words(data_complete, "Complete mails", False)
# print_pearson_result_words(data_unsure, "Unsure mails", False)
# print_spearman_result_words(data_unsure, "Unsure mails", False)
# print_pearson_result_words(data_difference, "Difference mails", False)
# print_spearman_result_words(data_difference, "Difference mails", False)

# Read the data of my annotions of the 92 unsure mails and get the number of mails matching to the
# actual ratings.
# my_data = pd.read_csv("Annotations_92emails_niklas_20220125.csv")
# positive, negative = separate_mails_with_respect_to_target_technical(my_data, data_unsure)

get_all_mail_data()