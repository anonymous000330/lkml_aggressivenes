# Studying Aggressiveness on the Linux Kernel Mailing List: A Methodological Challenge

## Downloaded content
This is a collection of scripts that were used to obtain the results, including the inter-rater agreement coefficients, the sentiment analysis, and the plots. All scripts and files that are contained in this package are briefly described.

- **annotations.csv**
  
  The raw data from the annotation. Each line describes the rating of one user (indicated by the column "user_id") of one e-mail (indicated by the column "email_id").

The "label" column contains the chosen overall label (we stored the labels in form of integers: -3: "strongly aggressive"; -2: "weakly aggressive"; 0: no label chosen (due to auto-generated, SPAM, or corrupted; 1: "neutral"; 2: "friendly").
The "target_*" indicate which target was selected ("1") or not selected ("0").
Same for "auto_generated", "spam", and "corrupted".
The column "not_sure" show whether an annotator has marked an e-mail annotation as "I am not sure".
Column "meta" indicates whether the annotator stated that the e-mail contains a discussion about communication issues.


- **annotations_batch1.csv**

  Same as above, including only the e-mails from the first batch.

- **annotations_batch2.csv**

  Same es above, including only the e-mails from the second batch.

- **annotators.csv**

  Background information about the annotatators, based on what the annotators stated themselves: The columns represent the following:

`user_id`: the ID of the annotator, 

`age`: the age range of the annotator, 

`gender`: the gender of the annotator, 

`experience`: the experience of the annotator on scale from 1 (novice) to 10 (expert),

`experience_compared`: the estimated experience compared to colleagues on scale from 1 (junior) to 5 (senior),

`coding languages`: the programming languages the anntotators are familiar with,

`paradigm_objectoriented`: how familiar the annotators were with object-oriented programming on scale from 0 (very unfamiliar) to 4 (very familiar),

`paradigm_functional`: how familiar the annotators were with functional programming on scale from 0 (very unfamiliar) to 4 (very familiar),

`paradigm_imperative`: how familiar the annotators were with imperative programming on scale from 0 (very unfamiliar) to 4 (very familiar),

`paradigm_logic`: how familiar the annotators were with logic programming on scale from 0 (very unfamiliar) to 4 (very familiar),

`num_opensource`: to how many open-source projects the annotator has contributed (0: zero open-source projects; 1: 1-2 open-source projects; 2: more than 2 open-source projects).

- **batch_*.csv**

  These files contain the tool results. "2019-04-15" refers to the first batch, "2019-10-18" refers to the second batch. For each batch, there is one file per for each combination of tools and preprocessings.

Tools: PerspectiveAPI, SentiStrength-SE, Stanford CoreNLP, VADER

Preprocessings: 

    - 1_minimal: Remove only citations
    
    - 2_simple: In addition to 1_minimal, remove also URLs, e-mail addresses, and signatures
  
    - 3_advanced: In addition to 2_simple, remove also developer names
  
    - 4_maximal: In addition to 3_advanced, remove also code snippets
The first column in the 'batch_*.csv' refers to the e-mail id, the remaining columns denote the tool result using the respective sentiment-analysis tool and e-mail preprocessing.

- **data_collection**

  This directory contains several files on how to collect the e-mail data, how to preprocess it, and how to format it for annotation. See more details in the separate README.md in the subdirectory for more details. Notice that we excluded some steps that would reveal e-mail author names, which we cannot publish due to data privacy concerns. However, we can provide further information upon request.

- **e-mail_contents.csv**
  
  The preprocessed e-mail contents (as seen on the website) with tokens for names, quotes, etc.

- **qualitative_evaluation.csv**

  The results of the manual investigation of the 76 ambiguous e-mails. The first column denotes the e-mail id, the second column the potential cause for the ambiguity (that we identified).

- **tutorial_e-mail_contents.csv**
  
  The preprocessed tutorial e-mail contents (as seen on the website) with tokens for names, quotes, etc. and the example annotations.

- **start.py**

  Contains code to obtain and print the results of the sentiment analyis tools as well as calculating the inter-rater-agreement for the ratings using different methods.

- **find_unsure_mails.py**

  Contains code to determine which mails are to be categorized as "with disagreement" with regard to the third ground truth.

- **unsure_mails_eval.py**

  Contains code to get the results shown in the excel spreadsheets, i.e., the correlations between overall label and targets for different groups of e-mails.

- **plot_agreement.py**

  Contains code that is used to create the plots seen in the paper and on the website. Also contains the code for the qualitative evaluation of the e-mails categorized as "ambiguous".

- **utils/label_mapping.py**

  Contains code to process the annotation data, i.e., accumulate it with respect to the e-mails and calculating the results for the different ground truths.

- **utils/combine_results_of_both_prestudies.py**

  Contains code to combine the two batches with 360 e-mails each to one data set.

- **utils/rater_agreement.py**

  Contains code to calculate the inter-rater agreement coefficients of the raters.

- **tools/comparison.py** 

  Contains code that compares the four tools by calculating their inter-rater agreement.

- **tools/perspective.py** 

  Contains code that executes the sentiment analysis tool "Perspective".

- **tools/sentistrength.py** 

  Contains code that executes the sentiment analysis tool "Sentistrength-SE".

- **tools/stanford.py** 

  Contains code that executes the sentiment analysis tool "Stanford".

- **tools/vader.py** 

  Contains code that executes the sentiment analysis tool "Vader".